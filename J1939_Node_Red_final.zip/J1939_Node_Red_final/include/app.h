#include <stdint.h>
#include <stdlib.h>
#include <asm/types.h>
#include "azure_c_shared_utility/shared_util_options.h"
#include "iothub.h"
#include "iothub_device_client_ll.h"
#include "iothub_message.h"
#include "iothubtransporthttp.h"
#include <pthread.h>
#include <sys/types.h>
#include "accelerometer.h"
#include "gyroscope.h"

/*String containing Hostname, Device Id & Device Key in the format:                         */
/*  "HostName=<host_name>;DeviceId=<device_id>;SharedAccessKey=<device_key>"                */
/*  "HostName=<host_name>;DeviceId=<device_id>;SharedAccessSignature=<device_sas_token>"    */
//static const char* connectionString = "HostName=iWaveOBD.azure-devices.net;DeviceId=004obd;SharedAccessKey=YnMPw7a0aHzg9CRgrh96rGvGxmG1kaLX2Bzg8z9H4uc=";
//static const char* connectionString = "HostName=iwaveiothub.azure-devices.net;DeviceId=001obd;SharedAccessKey=Czn5DKhLDZKQgDplsUNpjPetoTPO3Of4Ri77Y5aKFjY=";


//static const char* proxyHost = NULL;
//static int proxyPort = 0;
//static const char* data_to_upload_format = "qwertyuiocvbnm,dfghjklasdfghjk = %d\n";
//static uint32_t block_count = 0;
//char buffer[1000];
//clock_t begin;
//double time_spent;
char data_to_upload[1000];
#define SRC_XML_FILE            "/deviceConfig.xml"
#define PARENT_NODE_CLOUD       "cloud_config"

/*RMC*/
#define APP_WAKE  0
#define APP_SLEEP 1

#define TIME_STAMP          1
#define RMA_FIX_STATUS      2
#define RMA_CUR_LATITUDE    3
#define RMA_HEMISPHERE      4
#define RMA_CUR_LONGITUDE   5
#define RMA_GREENWICH       6
#define RMA_KNOT_SPEED      7
#define RMA_DIRECTION       8

/*GGA*/
#define TIME_STAMP      1
#define CUR_LATITUDE    2
#define HEMISPHERE      3
#define CUR_LONGITUDE   4
#define GREENWICH       5
#define FIX_STATUS      7
#define ALTITUDE        9
#define GEOID           11
#define BKP_FOLDER	"/home/root/BKP_FILES"
#define CURR_FOLDER	"/home/root/CURR_FILES"

#define ENABLE 1
#define DISABLE 0

#define WIFI_HOSTAPD_MODE 1
#define WIFI_STATION_MODE 2

#define BUFSIZE 1000

uint8_t PID_no;
char buf[BUFSIZE];
pthread_mutex_t lock;
pthread_mutex_t can_lock;
pthread_mutex_t udp_lock;

struct gps_rmc_t
{
    unsigned int hour;
    unsigned int minutes;
    unsigned int seconds;
    double latitude;
    double longitude;
    double speed;
    double direction;
    char nmea[200];
    int gps_valid;
    int gps_init_fix;
};
struct gps_gga_t
{
    char nmea[200];
    unsigned int hour;
    unsigned int minutes;
    unsigned int seconds;
    double latitude;
    double longitude;
    double altitude;
    double geoid;
    int gps_valid;
    int gps_init_fix;
};
struct gps_pkt
{
    struct gps_rmc_t gps_rmc;
    struct gps_gga_t gps_gga;
};
typedef struct _standard
{
    struct gps_pkt g_gps;
    char imei[64];
    int gps_fd;
    int ready;
    int gps_init_fix;
    int interrupt;
    int appSleep;
    char device_id[64];
    accelerometer_api_priv g_adata;
    gyroscope_api_priv g_gdata;
    volatile int con_status;
    int network_status;
    char dev_id[25];
    pthread_mutex_t pkt_lock;
    pthread_mutex_t send_lock;
    volatile int cloud_status;
    volatile int can_status;
    volatile int can_alert_not_available;
    volatile int can_alert_available;
    char con_string[256];
    int init_flag;
}_standard;
_standard standard_cli;
IOTHUB_DEVICE_CLIENT_LL_HANDLE device_ll_handle;

struct CAN {
        long int output;
        long int clutch_switch;
        long int brake_switch;
        long int cruise_state;
//        double output;
};
typedef struct CAN CAN_t;

struct obdType {
        uint16_t service;
    char Json_descript[30];
};
typedef struct obdType obdType_t;

struct iw_para {

        obdType_t obdType_ht[150];
    CAN_t CAN_ht[150];

};

typedef struct iw_para iw_para_t;

typedef iw_para_t *iw_hpara_t;

typedef struct j1939_parameters
{
    double eng_coolant_temp;
    double eng_speed;
    double accelerator_pedal_pos_1;
    double tachograph_veh_speed;
    double boost_pressure;
    double wheel_speed;
    int clutch_switch;
    int brake_switch;
    int cruice_cntl_state;
    double fuelLevel;
    double engine_total_fuel_used;
    int total_engine_hrs;
    double service_distance;
    double engine_speed;
    double axle_weight_1;
    double axle_weight_2;
    double axle_weight_3;
    double fuel_temp;
    double eng_oil_tmp1;
    double turbo_oil_temp;
    double eng_inter_cooler_temp;
    double eng_inter_cooler_thermostat_opening;
    int pto_state;
    int driver1_card_state;
    int driver2_card_state;
    int driver1_working_state;
    int driver2_working_state;
    int driver1_rel_state;
    int driver2_rel_state;
    char driver1_id[100];
    double latitude;
    double longtitude;
    double height;
    double odometer;
    char driver2_id[100];
    char vin[100];
    int seconds;
    int ptode_state;
    double high_res_total_fuel_used;
    double total_fuel_used;
    char imei[100];
    char mac_address[100];
}j1939_parameters;
pthread_t p_tid[7];

int gps_thread_flag;
int acc_thread_flag;
int can_thread_flag;
int reset_connection_flag;
int gyro_thread_flag;
int BLE_connection_status_flag;
int file_set_flag;

struct j1939_parameters j1939_p;
int j1939_can_init();
int j1939_can_deinit();
void j1939_filter_broad_cast_messages(__u32,uint8_t *,int);
int j1939_resp_recv(uint8_t *, int *,unsigned long int *);
int j1939_broad_cast_message_receive_thread();
int chartoint(char *val);
int i_strtok(char *src,char *dest);
int chartofloat(char *val,double *var);
int start_j1939_broad_cast_message_receive_thread();
//void i_hex_to_bin(uint8_t val,parse_dbc *p_dbc);
int j1939_get_clutch_cruice_cntrl_brake_switch_state(uint8_t *ar_raw_data, int len, unsigned long int pgn, int *clutch_switch_state,int *break_switch_state, int *cruice_cntrl_state);
int j1939_get_pto_state(uint8_t *ar_raw_data, int len, unsigned long int pgn, int *pto_state);
int j1939_tacho_get_drivers_id(uint8_t *ar_raw_data, int len,char *driver1_id,char *driver2_id);
int j1939_get_driver_card_state(uint8_t *ar_raw_data, int len, int *driver_card1_status, int *driver_card2_status);
int j1939_get_driver_working_state(uint8_t *ar_raw_data, int len, int *driver1_working_state, int *driver2_working_state);
int j1939_get_driver_rel_state(uint8_t *ar_raw_data, int len, int *driver1_rel_state, int *driver2_rel_state);
int send_data_to_ble(char *message);
int init (void*, void*);
//static IOTHUB_CLIENT_FILE_UPLOAD_GET_DATA_RESULT getDataCallback(IOTHUB_CLIENT_FILE_UPLOAD_RESULT result, unsigned char const ** data, size_t* size, void* context);
//static IOTHUB_CLIENT_FILE_UPLOAD_GET_DATA_RESULT getDataCallback(IOTHUB_CLIENT_FILE_UPLOAD_RESULT result, char ** data, size_t* size, void* context);
int frame_pkt_in_json(char *buffer,char *ts,char *device_id,char *mac_address,char *sw_version,j1939_parameters *data);
#define MAX_SIZE 1000
void obd_get_time (char *timebuf);
void process_data();
int read_cloud_config (char *connection_String);
int ntp_server_update();
int establish_network_connection();
int time_diff_seconds(struct timespec *time_end, struct timespec *time_start);
void reset_network_connection();
void process_pkts();
int app_deinit();
int decode_vehicle_identification_number(uint8_t *ar_raw_data, int len, char *vin);
int j1939_get_ptode_state(uint8_t *ar_raw_data, int len, unsigned long int pgn, int *pto_de_state);
int get_gps_data_wrapper(struct gps_pkt * gps);
int ParseGGA(struct gps_gga_t *gps_gga, size_t nbytes);
int ParseRMC(struct gps_rmc_t *gps_rmc, size_t nbytes);
int get_mac_address(char *interface,char *mac_address);
int time_diff_nano_seconds(struct timespec *time_end, struct timespec *time_start);
void data_packet_frame();
void BLE_connection_status();
int get_xml_content(char *filename, char *parent_node,char *name, char *value);
int decode_without_xml(uint8_t *ar_raw_data, int len, unsigned long int pgn,double *value);
int get_axle_location(uint8_t *ar_raw_data, int len, unsigned long int pgn,int *value);
void alert_handler();
int frame_alert_packet(char *buffer,char *ts,char *device_id,char *type,char *description);
int get_device_id(char *con_string);
void acc_thread (void);
void gyro_thread(void);
void gps_thread (void);
char parse_configuration(char *buffer);
int send_to_UDP(char * buffer);
void controller_thread (void);
void sys_sleep (void);
void sys_wake (void);
void controller_function(void);
int thread_init(void);
void sys_sleep_completed(void);
int deinit( );
void sys_wake_completed(void);
int push_device_to_sleep( );
int config_timer_wakeup( int option, int timer );
int config_can_wakeup( int option );
int wifi_init( int mode );
int wifi_deinit( int mode );
int CAN_Json_output( char * CAN_buffer, double battery_vol, char * ts);
int check_adc_voltage (double *volt);
int frame_gps_pkt_in_json(char * buffer,struct gps_rmc_t * gps_rmc,char * ts);

