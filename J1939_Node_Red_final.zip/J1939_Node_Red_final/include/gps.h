#ifndef __GPS_H_
#define __GPS_H_

#define GPS_NODE        "/dev/ttyUSB1"
int gps_init();
int gps_deinit(int gps_fd);
int get_gps_data(int gps_fd, char * nmea, size_t * g_nbytes, char *recv_data);
int agps_init();
#endif
