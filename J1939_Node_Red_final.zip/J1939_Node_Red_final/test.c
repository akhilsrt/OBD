#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <stdint.h>

int main () {
    uint16_t service;
    int service1;
    char temp[20] = "61444"; 
    service = (uint16_t)strtol(temp, NULL, 10);
    service1 = service;
    printf("The number(unsigned long integer) is %d\n", service);

    return(0);
}
