#include<stdio.h>
#include<stdlib.h>
#include"gps.h"
#include"app.h"
#include <stdint.h>
#include<string.h>
#include <signal.h>
#include <math.h>
#include <sys/time.h>
#include <time.h>
int get_gps_data_wrapper(struct gps_pkt * gps)
{
    int ret = 0;
    size_t nbytes;
    /*RMC*/
    ret = get_gps_data(standard_cli.gps_fd, "GPRMC", &nbytes, gps->gps_rmc.nmea);
    if(ret == 0)
    {
        ret = ParseRMC(&gps->gps_rmc, nbytes);
    }
    memset(gps->gps_rmc.nmea,0,sizeof( gps->gps_rmc.nmea));
    nbytes = 0;
    ret = get_gps_data(standard_cli.gps_fd, "GPGGA", &nbytes, gps->gps_gga.nmea);
    if(ret == 0)
    {
        ret = ParseGGA(&gps->gps_gga, nbytes);
    }
    return ret;
}
int ParseGGA(struct gps_gga_t *gps_gga, size_t nbytes)
{
    int j = 0;
    int k = 0;
    int l = 0;
    int ret = 0;
    char field[15][100] = {{0}};
    if (gps_gga == NULL || nbytes <= 0)
    {
        ret = -1;
    }
    else
    {
        if(gps_gga->nmea[0] != '\0')
        {
            for(j=0,k=0,l=0;j<nbytes;j++,l++)
            {
                for(;(gps_gga->nmea[j] != ',') && (gps_gga->nmea[j] != '\0');k++,j++)
                {
                    field[l][k] = gps_gga->nmea[j];
                }
                field[l][k] = '\0';
                k=0;
            }
            gps_gga->altitude = atof(field[ALTITUDE]);
            gps_gga->geoid = atof(field[GEOID]);
        }
    }
    //printf ("Altitude %f Geoid %f \n",gps_gga->altitude, gps_gga->geoid);
    return ret;
}
int ParseRMC(struct gps_rmc_t *gps_rmc, size_t nbytes)
{
    int j = 0;
    int k = 0;
    int l = 0;
    char field[20][100] = {0};
    //int i, z;
    static double prev_lat,prev_lon;
    //printf(" ParseRMC rmc_nmea %s \n",gps_rmc->nmea);
    if(gps_rmc->nmea[0] != '\0')
    {
        for(j=0,k=0,l=0;j<nbytes;j++,l++)
        {
            for(;(gps_rmc->nmea[j] != ',') && (gps_rmc->nmea[j] != '\0');k++,j++)
            {
                field[l][k] = gps_rmc->nmea[j];
                if(l > 16)
                    break;
            }
            field[l][k] = '\0';
            k=0;
        }

        if(*field[RMA_FIX_STATUS] != 'A')
        {
            //printf("\nGPS Not Valid\n");
            gps_rmc->gps_valid = 0;
            if (standard_cli.gps_init_fix == 1)
            {
                gps_rmc->latitude = prev_lat;
                gps_rmc->longitude = prev_lon;
            }
            else
            {
                gps_rmc->latitude  = 0.0;
                gps_rmc->longitude = 0.0;
                gps_rmc->speed = 0.0;
                gps_rmc->direction = 0.0;
            }
        }
        else
        {
            if (standard_cli.gps_init_fix == 0)
            {
                standard_cli.gps_init_fix = 1;
                printf("GPS is Valid!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!! \n");
            }
            gps_rmc->hour = atoi(field[TIME_STAMP]) / 10000;
            gps_rmc->minutes = (atoi(field[TIME_STAMP])/100) % 100;
            gps_rmc->seconds = atoi(field[TIME_STAMP]) % 100;

            gps_rmc->latitude = (fmod(atof(field[RMA_CUR_LATITUDE]),100.00)/60) +  (atoi(field[RMA_CUR_LATITUDE])/100);
            prev_lat = gps_rmc->latitude;
            if (*field[RMA_HEMISPHERE] != 'N')
                gps_rmc->latitude = -gps_rmc->latitude;

            gps_rmc->longitude = (fmod(atof(field[RMA_CUR_LONGITUDE]),100.00)/60 ) + (atoi(field[RMA_CUR_LONGITUDE])/100);
            prev_lon = gps_rmc->longitude;
            if (*field[RMA_GREENWICH] != 'E')
                gps_rmc->longitude = -gps_rmc->longitude;

            gps_rmc->speed = atof(field[RMA_KNOT_SPEED]);

            gps_rmc->direction = atof(field[RMA_DIRECTION]);

            gps_rmc->gps_valid = 1;
            //printf ("speed is %f knots\n",gps_rmc->speed);
            gps_rmc->speed = gps_rmc->speed * 1.852;
        }
    }
    //printf("gps_rmc->latitude : %f gps_rmc->longitude: %f  gps_rmc->speed : %fkm/hr gps_rmc->direction:%f deg\n",gps_rmc->latitude,gps_rmc->longitude, gps_rmc->speed, gps_rmc->direction);
    return gps_rmc->gps_valid;
}
