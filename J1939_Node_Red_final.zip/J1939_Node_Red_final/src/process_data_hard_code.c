#define _GNU_SOURCE
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <string.h>
#include <signal.h>
#include <errornos.h>
#include <app.h>
#include <sys/time.h>
#include <sys/stat.h>
#include <unistd.h>
#include <time.h>
#include "gsm.h"
#include "gps.h"
#include "stack.h"
#include<dirent.h>
FILE *cur_file_fp;
char *file_name = NULL;
char *file_name_txt = NULL;
int file_sequence_number = 1;
int counter = 0;
//Test Buffer Size increased from 6000 to 65535 to avoid segmentation fault. 
unsigned char test_buffer[65535];
//BackUp Test Buffer Size increased from 6000 to 65535 to avoid segmentation fault.
unsigned char test_buffer_bkp[65535];
unsigned char alert_test_buffer[6000];
uint32_t size2 = 0;
int alert_size = 0;
char buffer[31744] = {0};
int size1 = 0;
char file_name_zip[2000] = {0};
volatile int data_pkt_ready = 0;
volatile int data_file_ready = 0;
static int send_timer = 0;
static int bkp_timer = 0;
struct j1939_parameters j_dat;
int ble_data_ready_flag = 0;
volatile int gps_ready = 0;
volatile int bkp_count = 0;
volatile int send_status_bkp = 0;
volatile int curr_count = 0;
volatile int bkp_send_ready = 0;
volatile int bkp_send_stop = 0;
char bkp_file_name[2000] = {0};
int external_power_connected_send = 0;
int external_power_disconnected = 0;
int external_power_disconnected_send = 0;
int external_power_connected = 0;
int curr_send_status = 0;
volatile int bkp_file_send_ready = 0;
volatile int alert_ready = 0;
volatile int alert_send_ready = 0;
char *bkp_alert_file_name_json[200] = {0};
volatile int alert_bkp_count = 0;
int alert_file_read_ptr = 0;
volatile int send_to_ble = 0;

iw_para_t app;   // Configuration parameters, Data buffer and related variables
iw_hpara_t hApp = &app;

void sigalrm_handler( int sig )
{
    if(standard_cli.can_status == 1){
	printf("ALARMMMMMMMMMMMMMMMM \n");
	data_pkt_ready = 1;
	process_pkts();
	if(++bkp_timer == 10)
	{
		if(bkp_count > 0)
		{
			bkp_send_ready = 1;
		}
		bkp_timer = 0;
	}
	if(++send_timer == 590)
	{
		send_timer = 0;
		bkp_send_stop = 1;
	}
    }
}
#if 0 
static IOTHUB_CLIENT_FILE_UPLOAD_GET_DATA_RESULT getDataCallback(IOTHUB_CLIENT_FILE_UPLOAD_RESULT result,  unsigned char const ** data_to_cloud, size_t* size, void* context)
{
	(void)context;
	if (result == FILE_UPLOAD_OK)
	{
		if (data_to_cloud != NULL && size != NULL)
		{
			if(alert_send_ready == 1)
			{
				*data_to_cloud = &alert_test_buffer;
				*size = alert_size;
				alert_send_ready = 0;
			}
			else if(send_status_bkp == 1)
			{
				*data_to_cloud = &test_buffer_bkp;
				printf("size2 %d\n",size2);
				*size = size2;
				send_status_bkp = 0;
			}
			else
			{
				if (block_count < 1)
				{
					*data_to_cloud = &test_buffer;
					*size = size1;
					block_count++;
				}
				else
				{
					*data_to_cloud = NULL;
					*size = 0;
				}
			}
			printf("SIZE SENDING %d\n",*size);
			//printf("SIZE SENDING %d\n",size);
		}
		else
		{
			// The last call to this callback is to indicate the result of uploading the previous data block provided.
			// Note: In this last call, data and size pointers are NULL.
			(void)printf("Last call to getDataCallback (result for %dth block uploaded: %s)\r\n", block_count, MU_ENUM_TO_STRING(IOTHUB_CLIENT_FILE_UPLOAD_RESULT, result));
		}
	}
	else
	{
		//(void)printf("Received unexpected result %s\r\n", MU_ENUM_TO_STRING(IOTHUB_CLIENT_FILE_UPLOAD_RESULT, result));
	}
	return IOTHUB_CLIENT_FILE_UPLOAD_GET_DATA_OK;
}
#endif

#if 1 
void controller_function( void )
{
    int counter = 0;
    int rc = E_SUCCESS;
    standard_cli.init_flag = 0;
    gps_thread_flag = 0;
    acc_thread_flag = 0;
    can_thread_flag = 0;
    gyro_thread_flag = 0;
    reset_connection_flag = 0;
    BLE_connection_status_flag = 0;
    while(1){
        if( access( "filename", F_OK ) == 0 ) {
            sleep(2);
init:       
            printf("Before CAN LOCK in controller function\n");
            pthread_mutex_lock(&can_lock);
            printf("After CAN LOCK in controller function\n");
            sleep(2);
            if(standard_cli.init_flag == 0){
//                rc = CAN_init();
                printf("Before J1939 CAN init\n");
                rc = j1939_can_init();
                printf("After J1939 CAN init\n");
                if(rc != E_SUCCESS){
                    counter++;
                    printf("Counter Value is *************************%d\n",counter);
//                    CAN_deinit();
//                    printf("Before J1939 CAN Deinit\n");
//                    j1939_can_deinit();
//                    printf("After J1939 CAN Deinit\n");
                    printf("Before CAN UNLOCK in controller function\n");
                    pthread_mutex_unlock(&can_lock);
                    printf("After CAN UNLOCK in controller function\n");
                    if(counter > 4){
                        rc = thread_init();
                        if (rc == E_FAILURE)
                        {
                            printf("thread_init failed \n");
                        }
                        sleep( 2 );

                        sys_sleep();
//                        rc = config_timer_wakeup( ENABLE, 60 );
                        
                        rc = config_can_wakeup(ENABLE);
                        if (rc == E_FAILURE)
                        {
                            printf("config_can_wakeup failed \n");
                        }
                        rc = push_device_to_sleep();
                        if (rc == E_FAILURE)
                        {
                            printf("sys_sleep failed \n");
                        }
                        sys_wake();
                        counter = 0;
                        goto init;
                    }
                }
                else
                {
                    standard_cli.can_status = 1;
                    rc = thread_init();
                    if (rc == E_FAILURE)
                    {
                        printf("thread_init failed \n");
                    }
                    sleep( 5 );
                    standard_cli.init_flag = 1;
                }
            }
            else{
                sys_sleep();
                rc = config_can_wakeup(ENABLE);
                if (rc == E_FAILURE)
                {
                    printf("config_can_wakeup failed \n");
                }
                rc = push_device_to_sleep();
                if (rc == E_FAILURE)
                {
                    printf("sys_sleep failed \n");
                }
                sys_wake();
//                rc = CAN_init();
//                j1939_can_init();
                rc = thread_init();
                if (rc == E_FAILURE)
                {
                    printf("thread_init failed \n");
                }
                sleep( 5 );
            }
        }
        sleep(1);
    }
    return;
}

void sys_sleep (void)
{
    int rc = E_SUCCESS;
    printf("system sleep in sys_sleep()\n");
//    char ts[64]={0};
    standard_cli.interrupt = 1;
    standard_cli.appSleep = APP_SLEEP;
    standard_cli.can_status = 0;
    
    while( 1 )
    {

        if( ( ( acc_thread_flag == 0 ) && ( reset_connection_flag == 0 ) && ( gps_thread_flag == 0 ) && ( can_thread_flag == 0 ) && ( gyro_thread_flag == 0 ) && ( BLE_connection_status_flag == 0 ) ) == 0 )
        {
            printf("%s - All threads got exited \n", __FUNCTION__ );
            break;
        }
        sleep( 1 );
    }

    sleep(2);//to wait till all thread_exit
    rc = deinit();
    if (rc != E_SUCCESS)
        printf ("hw_deinit failed\n");

    rc = acc_deinit();
    if (rc != E_SUCCESS)
        printf ("ACC_deinit failed\n");

    sleep(2);

    rc = gyro_deinit();
    if (rc != E_SUCCESS)
        printf ("Gyro_deinit failed\n");

    sleep(2);
#if 0
    rc = j1939_can_deinit();
    if (rc != E_SUCCESS)
        printf ("CAN_deinit failed\n");
#endif
    rc = wifi_deinit( WIFI_HOSTAPD_MODE );
    if (rc != E_SUCCESS)
        printf ("Wifi_deinit failed\n");

    sleep(2);

    gps_deinit(standard_cli.gps_fd);

    sleep(2);

    gsm_modem_off();

    sys_sleep_completed();// to indicate sleep completion status to library

    return;
}

void sys_wake (void)
{
    int rc = E_SUCCESS;
    standard_cli.interrupt = 0;
    char device_id[100] = {0};
    standard_cli.appSleep = APP_WAKE;
    char connection_String[200];
//    int sockfd; /* socket */
//    int clientlen; /* byte size of client's address */
//    struct sockaddr_in clientaddr; /* client addr */
    //    struct hostent *hostp; /* client host info */
    //    char *hostaddrp; /* dotted decimal host addr string */
//    int optval;
//    int n;
    standard_cli.con_status = -1;
    standard_cli.cloud_status = -1;
    standard_cli.can_status = 1;
    standard_cli.network_status = 0;
    standard_cli.can_alert_not_available = 0;
    standard_cli.can_alert_available = 0;
    device_ll_handle = NULL;
    printf("!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!! START !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!\n");
    //  rc = convert_existing_file();
    printf("Converted all existing files ---- rc %d\n",rc);
    rc = init(NULL, NULL);
    if(rc != 0)
    {
        printf("init() failed ---- rc %d\n",rc);
    }
    else
    {
        rc = check_gsm_modem_status();
        if(rc != 0)
        {
            /* Turning on the GSM modem */
            rc = gsm_modem_on();
            printf("gsm_modem_on() Return value = %d\n",rc);
        }
    }
    if(rc == E_SUCCESS)
    {
        rc = establish_network_connection();
        if(rc == 0)
        {
            standard_cli.con_status = 1;
        }
        rc = agps_init();
        printf("quectel_agps_init() Return value = %d\n",rc);
        //      standard_cli.gps_fd = gps_init();
        //      printf("gps_init() Return value = %d\n",standard_cli.gps_fd);
    }
    
    rc = wifi_init( WIFI_HOSTAPD_MODE );
    if(rc != E_SUCCESS)
        printf("Wifi init failed at callback option\n");
    
    sleep(2);
    
    rc = get_gsm_imei(device_id);
    if(rc == E_SUCCESS)
    {
        strcpy(standard_cli.device_id, device_id);
        printf("Device ID [%s]\n", standard_cli.device_id);
    }
    memset(connection_String, 0, sizeof(connection_String));
    memset(standard_cli.con_string,0,sizeof(standard_cli.con_string));
    //  read_cloud_config(connection_String);
    strcpy(standard_cli.con_string,connection_String);
    get_device_id(connection_String);    


    rc = acc_init();
    if(rc != E_SUCCESS)
        printf("Acc init failed at callback option\n");

    sleep(2);

    rc = gyro_init();
    if(rc != E_SUCCESS)
        printf("Gyro init failed at callback option\n");

    sleep(2);

    standard_cli.gps_fd = gps_init();
    if (standard_cli.gps_fd == E_FAILURE)
    {
        printf("gps init faild\n");
    }

    sleep(2);

#if 0
    rc = wifi_init( WIFI_HOSTAPD_MODE );
    if(rc != E_SUCCESS)
        printf("Wifi init failed at callback option\n");
#endif
    standard_cli.appSleep = APP_WAKE;

    return;
}

#endif

void process_data()
{
    uint8_t data[2000]={0};
    int length;
    FILE *file;
    int n = 0;
    int m = 0;
    int j = 0;
    unsigned long int var_pgn = 0;
    int rc = 0, i;
    signal(SIGALRM, sigalrm_handler);
    //struct j1939_data *j_ptr;
    //	int start = 0;
    int ptode_state = 0;
    int cruice_state = 0;
    int break_state = 0;
    int clutch_state = 0;
    int pto_state = 0;
    int driver1_card_state = 0;
    int driver2_card_state = 0;
    int driver1_working_state = 0;
    int driver2_working_state = 0;
    int driver1_rel_state = 0;
    int driver2_rel_state = 0;
    char driver1_id[70] = {0};
    char driver2_id[70] = {0};
    char vin[100] = {0};
    int len = 0;
    char can_temp[20] = {0};
    uint16_t service1;
    char *main_buffer = NULL;
    char ts[50];
    double bat_volt = 0;
    size_t size = 0;
    uint8_t buff_app[8] = {0x0};
    double de_value;
//    char dtc[500]={0};
    int fail_counter = 0;
    int axle_location = 0;
    memset(j_dat.vin,0,sizeof(j_dat.vin));
    memset(j_dat.driver1_id,0,sizeof(j_dat.driver1_id));
    memset(j_dat.driver2_id,0,sizeof(j_dat.driver2_id));
    alarm(1);
    if( can_thread_flag == 1 )
    {
        //        printf("INSIDE CAN THREAD FLAG ****************\n");
        while(!standard_cli.interrupt)
        {
            //            printf("INSIDE STANDARD CLI***************\n");
            if( access( "filename", F_OK ) == 0 ) {
                if(standard_cli.appSleep == APP_SLEEP)
                {
                    break;
                }
                if(standard_cli.can_status == 1)
                {
                    //                printf("INSIDE CAN STATUS *****************\n");
                    //            printf("Before CAN_LOCK in process thread\n");
                    pthread_mutex_lock(&udp_lock);
                    //            printf("After CAN_LOCK in process thread\n");
                    file = fopen("filename", "r");
                    if(file == NULL)
                    {
                        printf("Error!");
                        exit(1);
                    }
                    rc = fseek(file, 0, SEEK_END); /* Go to end of file */
                    if(rc != E_SUCCESS)
                    {
                        printf("FSEEK FAILED\n");
                    }
                    size = ftell(file);
                    rewind(file);
                    main_buffer = malloc((size + 1) * sizeof(*main_buffer));
                    fread(main_buffer, size, 1, file);
                    main_buffer[size] = '\0';
                    rc = fclose(file);
                    if(rc != E_SUCCESS)
                    {
                        printf("File closing Failed\n");
                    }
                    memset(can_temp, 0, sizeof(can_temp));
                    if(file_set_flag == 0){
                        len = 0;
                        m = 0;
                        n = 0;
                        PID_no = 0;
                        memset(&hApp->obdType_ht,0,sizeof(hApp->obdType_ht));
                        while(main_buffer[len] !='\0')
                        {
                            while(main_buffer[len]!=',')
                            {
                                can_temp[j]=main_buffer[len];
                                len++;
                                j++;
                            }
                            len++;
                            j=0;
                            hApp->obdType_ht[m].service = (uint16_t) strtol(can_temp,NULL,10);
                            //                        printf("%x\r\n",hApp->obdType_ht[m].service);
                            m++;
                            memset(can_temp, 0, sizeof(can_temp));
                            while(main_buffer[len]!='*')
                            {
                                can_temp[j]=main_buffer[len];
                                len++;
                                j++;
                            }
                            if(main_buffer[len]=='\r')
                            {
                                len++;
                            }
                            len++;
                            j=0;
                            strcpy(hApp->obdType_ht[n].Json_descript, can_temp);
                            //                        printf("%s\r\n",hApp->obdType_ht[n].Json_descript);
                            n++;
                            memset(can_temp, 0, sizeof(can_temp));
                            PID_no++;
                            file_set_flag = 1;
                        }
                    }
                    //                printf("\r\nService Value in CAN thread%x\r\n",hApp->obdType_ht[0].service);
                    //                printf("\r\nDescriptor Value in CAN thread%s\r\n",hApp->obdType_ht[0].Json_descript);
                    for (i=0;i<PID_no;i++)
                    {
                        memset(buff_app,0,sizeof(buff_app));
                        //                                printf("\r\n%ld\r\n",(long)hApp->obdType_ht[i].service);
                        //                                printf("\r\n%s\r\n",hApp->obdType_ht[i].Json_descript);
                        service1 = (uint16_t)hApp->obdType_ht[i].service;
                        //                    printf("Service Value is %d\n",service1);
                        memset(&data,0,sizeof(data));
                        memset(driver1_id,0,sizeof(driver1_id));
                        memset(driver2_id,0,sizeof(driver2_id));
                        memset(vin,0,sizeof(vin));
                        length = 0;
                        var_pgn = 0;
                        de_value = 0;
                        axle_location = 0;
                        rc = j1939_recv_broadcast_response(data,&length,&var_pgn);
                        if(rc != 0){
                            printf ("CAN_resp_recv failed %d\n",rc);
                            fail_counter++;
                            printf("Fail Counter Value is ########################%d\n",fail_counter);
                            if(fail_counter > 10){
                                standard_cli.init_flag = 1;
                                fail_counter = 0;
                                pthread_mutex_unlock(&can_lock);
                            }

                        }    
                        else
                        {
                            fail_counter = 0;
//                        }
                            //                    }
//                            if(var_pgn == 65265 || var_pgn == 61444 || var_pgn == 65132 || var_pgn == 61443 || var_pgn == 65276 || var_pgn == 65253 || var_pgn == 65257 || var_pgn == 65216 || var_pgn == 65262 || var_pgn == 65258 || var_pgn == 65131 || var_pgn == 65260 || var_pgn == 64932 || var_pgn == 65217 || var_pgn == 64777)
                                //                            if(var_pgn == 61444 || var_pgn == 65262)
                                //                              if(var_pgn == service1)
                                                      switch(service1)
                            {
                                //                                printf("##################################################################");
                                //                    printf("DEBUG : RAW RESPONSE  %s L#%d \n",__func_, _LINE__);
                                //                    for(k=0;k<length;k++)
                                //                    {
                                //                        printf("Raw Value*******************%X \n",data[k]);
                                //                    }
                                //                    printf("\n");
                                //rc = decode_without_xml(data,length,var_pgn,&de_value);
                                case 61444:
                                if(var_pgn == 61444)
                                {
                                    rc = decode_without_xml(data,length,var_pgn,&de_value);
                                    j_dat.eng_speed = de_value;
                                    printf("Engine_Speed\r\n%f\r\n",de_value);
                                    hApp->CAN_ht[i].output = j_dat.eng_speed;
                                    //                                printf("\r\n%ld\r\n",hApp->CAN_ht[i].output);
                                    //                                enginespeed = j_dat.eng_speed;
                                    //                                printf("Engine speed Value is %f\n",enginespeed);
                                    //                                goto count;
                                }				
                                                            break;
                                                            case 65265:
                                if(var_pgn == 65265)
                                {
                                                                    rc = decode_without_xml(data,length,var_pgn,&de_value);
                                                                    j_dat.wheel_speed = de_value;
                                    printf("Wheel_Speed\r\n%f\r\n",de_value);
                                    hApp->CAN_ht[i].output = de_value;
//                                                                  break;
                                    j1939_get_clutch_cruice_cntrl_brake_switch_state(data,length,var_pgn,&clutch_state,&break_state,&cruice_state);
                                    j1939_get_pto_state(data,length,var_pgn,&pto_state);
                                    if(clutch_state == E_CLUTCH_SWITCH_PEDAL_RELEASED)
                                    {
                                        j_dat.clutch_switch= 0;
                                        printf("Clutch_Switch\r\n%d\r\n",j_dat.clutch_switch);
                                        hApp->CAN_ht[i].clutch_switch = j_dat.clutch_switch;
                                    }
                                    else if(clutch_state == E_CLUTCH_SWITCH_PEDAL_DEPRESSED)
                                    {
                                        j_dat.clutch_switch = 1;
                                        hApp->CAN_ht[i].clutch_switch = j_dat.clutch_switch;
                                        printf("Clutch_Switch\r\n%d\r\n",j_dat.clutch_switch);
                                    }

                                    if(break_state == E_BREAK_SWITCH_PEDAL_RELEASED)
                                    {
                                        j_dat.brake_switch = 0;
                                        printf("Brake_Switch\r\n%d\r\n",j_dat.brake_switch);
                                        hApp->CAN_ht[i].brake_switch = j_dat.brake_switch;
                                    }
                                    else if(break_state == E_BREAK_SWITCH_PEDAL_DEPRESSED)
                                    {
                                        j_dat.brake_switch = 1;
                                        printf("Brake_Switch\r\n%d\r\n",j_dat.brake_switch);
                                        hApp->CAN_ht[i].brake_switch = j_dat.brake_switch;
                                    }

                                    if(cruice_state == E_CRUICE_CNTRL_OFF)
                                    {
                                        j_dat.cruice_cntl_state = 0;
                                        printf("cruice_cntl_state\r\n%d\r\n",j_dat.cruice_cntl_state);
                                        hApp->CAN_ht[i].cruise_state = j_dat.cruice_cntl_state;
                                    }
                                    else if(cruice_state == E_CRUICE_CNTRL_ON)
                                    {
                                        j_dat.cruice_cntl_state = 1;
                                        printf("cruice_cntl_state\r\n%d\r\n",j_dat.cruice_cntl_state);
                                        hApp->CAN_ht[i].cruise_state = j_dat.cruice_cntl_state;
                                    }
                                }
                                                            break;
                                                            case 65132:
                                if(var_pgn == 65132)
                                {
                                                                   rc = decode_without_xml(data,length,var_pgn,&de_value);
                                    j_dat.tachograph_veh_speed = de_value;
                                    hApp->CAN_ht[i].output = j_dat.tachograph_veh_speed;

                                    rc = j1939_get_driver_card_state(data,length,&driver1_card_state,&driver2_card_state);
                                    if(rc){
                                        if(driver1_card_state == E_DRIVER_CARD_1_NOT_PRESENT)
                                        {
                                            j_dat.driver1_card_state = 0;
                                            hApp->CAN_ht[i].output = j_dat.driver1_card_state;
                                        }
                                        else if(driver1_card_state == E_DRIVER_CARD_1_PRESENT)
                                        {
                                            j_dat.driver1_card_state = 1;
                                            hApp->CAN_ht[i].output = j_dat.driver1_card_state;
                                        }
                                        if(driver2_card_state == E_DRIVER_CARD_2_NOT_PRESENT)
                                        {
                                            j_dat.driver2_card_state = 0;
                                            hApp->CAN_ht[i].output = j_dat.driver2_card_state;
                                        }
                                        else if(driver2_card_state == E_DRIVER_CARD_2_PRESENT)
                                        {
                                            j_dat.driver2_card_state = 1;
                                            hApp->CAN_ht[i].output = j_dat.driver2_card_state;
                                        }
                                        j1939_get_driver_working_state(data,length,&driver1_working_state,&driver2_working_state);
                                        j_dat.driver1_working_state = driver1_working_state;
                                        hApp->CAN_ht[i].output = j_dat.driver1_working_state;

                                        j_dat.driver2_working_state = driver2_working_state;
                                        hApp->CAN_ht[i].output = j_dat.driver2_working_state;

                                        j1939_get_driver_rel_state(data,length,&driver1_rel_state,&driver2_rel_state);
                                        j_dat.driver1_rel_state = driver1_rel_state;
                                        hApp->CAN_ht[i].output = j_dat.driver1_rel_state;

                                        j_dat.driver2_rel_state = driver2_rel_state;
                                        hApp->CAN_ht[i].output = j_dat.driver2_rel_state;
                                    }
                                }
                                                            break;
                                                            case 61443:
                                if(var_pgn == 61443)
                                {
                                                                    rc = decode_without_xml(data,length,var_pgn,&de_value);
                                    j_dat.accelerator_pedal_pos_1 = de_value;
                                    hApp->CAN_ht[i].output = j_dat.accelerator_pedal_pos_1;
                                }
                                                            break;
                                                            case 65276:
                                if(var_pgn == 65276)
                                {
                                                                    rc = decode_without_xml(data,length,var_pgn,&de_value);
                                    j_dat.fuelLevel = de_value;
                                    hApp->CAN_ht[i].output = j_dat.fuelLevel;
                                }
                                                            break;
                                                            case 65257:
                                if(var_pgn == 65257)
                                {   
                                                                    rc = decode_without_xml(data,length,var_pgn,&de_value);
                                    j_dat.total_fuel_used = de_value;
                                    hApp->CAN_ht[i].output = j_dat.total_fuel_used;
                                }
                                                            break;
                                                            case 65253:
                                if(var_pgn == 65253)
                                {
                                                                    rc = decode_without_xml(data,length,var_pgn,&de_value);
                                    j_dat.total_engine_hrs = de_value;
                                    hApp->CAN_ht[i].output = j_dat.total_engine_hrs;
                                }
                                                            break;
                                                            case 65216:
                                if(var_pgn == 65216)
                                {
                                                                    rc = decode_without_xml(data,length,var_pgn,&de_value);
                                    j_dat.service_distance = de_value;
                                    hApp->CAN_ht[i].output = j_dat.service_distance;
                                }
                                                            break;
                                                            case 65258:
                                if(var_pgn == 65258)
                                {
                                                                    rc = decode_without_xml(data,length,var_pgn,&de_value);
                                    j_dat.axle_weight_1 = de_value;
                                    hApp->CAN_ht[i].output = j_dat.axle_weight_1;
                                    rc = get_axle_location(data,length,var_pgn,&axle_location);
                                    //printf("AXLE_LOCATION %d\n",axle_location,de_value);
                                    if(rc == 0)
                                    {
                                        if(axle_location == 1)
                                        {
                                            j_dat.axle_weight_1 = de_value;
                                            hApp->CAN_ht[i].output = j_dat.axle_weight_1;
                                        }
                                        else if(axle_location == 2)
                                        {
                                            j_dat.axle_weight_2 = de_value;
                                            hApp->CAN_ht[i].output = j_dat.axle_weight_2;
                                        }
                                        else if(axle_location == 3)
                                        {
                                            j_dat.axle_weight_3 = de_value;
                                            hApp->CAN_ht[i].output = j_dat.axle_weight_3;
                                        }
                                        else
                                        {
                                        }
                                    }
                                }
                                                            break;
                                                            case 65217:
                                if(var_pgn == 65217)
                                {
                                                                    rc = decode_without_xml(data,length,var_pgn,&de_value);
                                    j_dat.odometer = de_value;
                                    hApp->CAN_ht[i].output = j_dat.odometer;
                                }
                                                            break;
                                                            case 64777:
                                if(var_pgn == 64777)
                                {
                                                                    rc = decode_without_xml(data,length,var_pgn,&de_value);
                                    j_dat.high_res_total_fuel_used = de_value;
                                    hApp->CAN_ht[i].output = j_dat.high_res_total_fuel_used;
                                }
                                                            break;
                                                            case 65262:
                                if(var_pgn == 65262)
                                {
                                                                    rc = decode_without_xml(data,length,var_pgn,&de_value);
                                    j_dat.eng_coolant_temp = de_value;
                                    hApp->CAN_ht[i].output = j_dat.eng_coolant_temp;
                                }
                                                            break;
                                                            case 65260:
                                if(var_pgn == 65260)
                                {
                                                                    rc = decode_without_xml(data,length,var_pgn,&de_value);
                                    memset(vin,0,sizeof(vin));
                                    decode_vehicle_identification_number(data,length,vin);
                                    len = 0;
                                    len = strlen(vin);
                                    strncpy(j_dat.vin,vin,len+2);
                                    hApp->CAN_ht[i].output = *j_dat.vin;
                                }
                                                            break;
                                                            case 65131:
                                if(var_pgn == 65131)
                                {
                                    memset(driver1_id,0,sizeof(driver1_id));
                                    memset(driver2_id,0,sizeof(driver1_id));
                                    memset(j_dat.driver1_id,0,sizeof(j_dat.driver1_id));
                                    memset(j_dat.driver2_id,0,sizeof(j_dat.driver2_id));
                                    j1939_tacho_get_drivers_id(data,length,driver1_id,driver2_id);
                                    len = 0;
                                    len = strlen(driver1_id);
                                    strncpy(j_dat.driver1_id,driver1_id,len+2);
                                    len = 0;
                                    len = strlen(driver2_id);
                                    strncpy(j_dat.driver2_id,driver2_id,len+2);
                                }
                                                            break;
                                                            case 64932:
                                if(var_pgn == 64932)
                                {
                                    j1939_get_ptode_state(data,length,var_pgn,&ptode_state);
                                }
                                if(j_dat.high_res_total_fuel_used > 0)
                                {
                                    j_dat.engine_total_fuel_used = j_dat.high_res_total_fuel_used;
                                    hApp->CAN_ht[i].output = j_dat.engine_total_fuel_used;
                                }
                                else
                                {
                                    j_dat.engine_total_fuel_used = j_dat.total_fuel_used;
                                    hApp->CAN_ht[i].output = j_dat.engine_total_fuel_used; 
                                }
                                if(ptode_state == 1 || pto_state == 5)
                                {
                                    j_dat.pto_state = 1;
                                    hApp->CAN_ht[i].output = j_dat.pto_state;
                                }
                                if(ptode_state == 0 && pto_state == 0)
                                {
                                    j_dat.pto_state = 0;
                                    hApp->CAN_ht[i].output = j_dat.pto_state;
                                }
                                else if((ptode_state == 2 || ptode_state == 3 || ptode_state == 0) && (pto_state == 5))
                                {
                                    j_dat.pto_state = 1;
                                    hApp->CAN_ht[i].output = j_dat.pto_state;
                                }
                                else if(pto_state == 31 || (pto_state == 0  && ptode_state == 1))
                                {
                                    j_dat.pto_state = 1;
                                    hApp->CAN_ht[i].output = j_dat.pto_state;
                                }
                                else if((pto_state == 31 || pto_state == 0) && (ptode_state == 2 || ptode_state == 3 || ptode_state == 0))
                                {
                                    j_dat.pto_state = 1;
                                    hApp->CAN_ht[i].output = j_dat.pto_state;
                                }
                                                            break;
                            }
                            }
                        }
#if 0
                    else
                    {
                        continue;	
                    }
#endif
                    //                }
                    //                }
                    //            printf("Before CAN_LOCK in process thread\n");
                    i = 0;
                    memset(ts,0,sizeof(ts));
                    obd_get_time(ts);
                    check_adc_voltage(&bat_volt);
                    memset(buffer,0,sizeof(buffer));
                    CAN_Json_output(buffer, bat_volt, ts);
                    //        printf("CAN Buffer value = %s \n",buffer);
                    pthread_mutex_unlock(&udp_lock);
                }
                    //            printf("After CAN_LOCK in process thread\n");
            }
        }
    
    //            i = 0;
#if 0
    printf("Decoded Value is %f\n***********************",de_value);
    memset(ts,0,sizeof(ts));
    obd_get_time(ts);
    memset(buffer,0,sizeof(buffer));
    frame_pkt_in_json(buffer,ts,j1939_p.imei,j1939_p.mac_address,"SW_REL3.5",&j_dat);
    // check_adc_voltage(&bat_volt);
    //            memset(buffer,0,sizeof(buffer));
    //CAN_Json_output(buffer, bat_volt, ts);
    sleep(2);
    printf("CAN Buffer value = %s \n",buffer);
    /*!< Send gps packet to cloud*/
    //rc = send_data_to_cloud(buffer);
    /*Send data to UDP port*/
    pthread_mutex_unlock(&can_lock);
    rc = send_to_UDP(buffer);
#endif  
}  
else
{
}
can_thread_flag = 0;
printf("can_thread exits\n");
//return;
}
int frame_pkt_in_json(char *buffer,char *ts,char *device_id,char *mac_address,char *sw_version,j1939_parameters *data)
{
    //printf("deviceId : %s,macAddress : %s,startDate %s , swVersion %s , vehicleId %s , tcoVehicleSpeed :%f, vehicleSpeed :%f, clutchSwitch :%d, brakeSwitch :%d, cruiseControlState :%d, ptoState :%d, pedalPosition :%f, odometer :%f, fuelLevel :%f, totalConsumption :%f, totalEngineHours :%d, nextService :%f, engineTemperature :%f, engineSpeed :%f, axleWeight1 :%f, axleWeight2 :%f, axleWeight3 :%f, driver1CardId %s , driver1CardState :%d, driver1WorkingState :%d, driver1RelState :%d, driver2CardId %s , driver2CardState :%d, driver2WorkingState :%d, driver2RelState :%d, longitude :%f, latitude :%f Height %f\n",device_id,mac_address,ts,sw_version,data->vin,data->tachograph_veh_speed,data->wheel_speed,data->clutch_switch,data->brake_switch,data->cruice_cntl_state,data->pto_state,data->accelerator_pedal_pos_1,data->odometer,data->fuelLevel,data->engine_total_fuel_used,data->total_engine_hrs,data->service_distance,data->eng_coolant_temp,data->eng_speed,data->axle_weight_1,data->axle_weight_2,data->axle_weight_3,data->driver1_id,data->driver1_card_state,data->driver1_working_state,data->driver1_rel_state,data->driver2_id,data->driver2_card_state,data->driver2_working_state,data->driver2_rel_state,standard_cli.g_gps.gps_rmc.latitude,standard_cli.g_gps.gps_rmc.longitude,standard_cli.g_gps.gps_gga.altitude);
    printf("frame_pkt_in_json Engine Temperature :%f ++\n",data->eng_coolant_temp);
    printf("frame_pkt_in_json Engine Temperature :%f ++\n",data->eng_speed);
    sprintf(buffer,"{\"deviceId\":\"%s\",\"macAddress\":\"%s\",\"startDate\":\"%s\",\"swVersion\":\"%s\",\"vehicleId\":\"%s\",\"tcoVehicleSpeed\":%f,\"vehicleSpeed\":%f,\"clutchSwitch\":%d,\"brakeSwitch\":%d,\"cruiseControlState\":%d,\"ptoState\":%d,\"pedalPosition\":%f,\"odometer\":%f,\"fuelLevel\":%f,\"totalConsumption\":%f,\"totalEngineHours\":%d,\"nextService\":%f,\"engineTemperature\":%f,\"engineSpeed\":%f,\"axleWeight1\":%f,\"axleWeight2\":%f,\"axleWeight3\":%f,\"driver1CardId\":\"%s\",\"driver1CardState\":%d,\"driver1WorkingState\":%d,\"driver1RelState\":%d,\"driver2CardId\":\"%s\",\"driver2CardState\":%d,\"driver2WorkingState\":%d,\"driver2RelState\":%d,\"longitude\":%f,\"latitude\":%f,\"height\":%f}\n",device_id,mac_address,ts,sw_version,data->vin,data->tachograph_veh_speed,data->wheel_speed,data->clutch_switch,data->brake_switch,data->cruice_cntl_state,data->pto_state,data->accelerator_pedal_pos_1,data->odometer,data->fuelLevel,data->engine_total_fuel_used,data->total_engine_hrs,data->service_distance,data->eng_coolant_temp,data->eng_speed,data->axle_weight_1,data->axle_weight_2,data->axle_weight_3,data->driver1_id,data->driver1_card_state,data->driver1_working_state,data->driver1_rel_state,data->driver2_id,data->driver2_card_state,data->driver2_working_state,data->driver2_rel_state,standard_cli.g_gps.gps_rmc.latitude,standard_cli.g_gps.gps_rmc.longitude,standard_cli.g_gps.gps_gga.altitude);
    printf("frame_pkt_in_json --\n");
    return 0;
}

char parse_configuration(char *buffer){
    //    char temp[20];
    //    int len=0;
    //    int j=0;
    //    int m=0;
    FILE *file;
    int rc = E_SUCCESS;
    //    int n=0;
    //    char *main_buffer = NULL;
    //    size_t size = 0;
    //    uint16_t k;
    PID_no=0;
    file = fopen("filename", "w");
    if(file == NULL)
    {
        printf("Error!");
        exit(1);
    }
    int results = fputs(buffer, file);
    if (results == EOF) {
        printf("No contents inside file\n");
    }
    rc = fclose(file);
    if(rc == E_SUCCESS)
    {
        printf("File closed successfully\n");
    }
    return 0;
}

#if 0
char parse_configuration(char *buffer){
    char temp[20];
    int len=0;
    int j=0;
    int m=0;
    int n=0;
    //    uint16_t k;
    memset(temp, 0, sizeof(temp));
    memset(&hApp->obdType_ht,0,sizeof(hApp->obdType_ht));
    PID_no=0;
    while(buffer[len] !='\0')
    {
        while(buffer[len]!=',')
        {
            temp[j]=buffer[len];
            len++;
            j++;
        }
        len++;
        j=0;
        printf("Service Value is %s\n",temp);
        //         hApp->obdType_ht[m].service = strtol(temp,NULL,10);
        hApp->obdType_ht[m].service = (uint16_t) strtol(temp,NULL,10);
        //strcpy(hApp->obdType_ht[m].service, temp);
        printf("%ld\r\n",(long)hApp->obdType_ht[m].service);
        m++;
        memset(temp, 0, sizeof(temp));
        while(buffer[len]!='*')
            //while(buffer[len]!='\r' || buffer[len]!='\n')
        {
            temp[j]=buffer[len];
            len++;
            j++;
        }
        if(buffer[len]=='\r')
        {
            len++;
        }
        len++;
        j=0;
        strcpy(hApp->obdType_ht[n].Json_descript, temp);
        printf("%s\r\n",hApp->obdType_ht[n].Json_descript);
        n++;
        memset(temp, 0, sizeof(temp));
        PID_no++;
    }
    //k =(uint16_t) strtol(hApp->obdType_ht[0].service,NULL,16);
    //sscanf(hApp->obdType_ht[0].service, "%x", &k)
    printf("\r\n%ld\r\n",(long)hApp->obdType_ht[0].service);
    printf("\r\n%s\r\n",hApp->obdType_ht[0].Json_descript);
    return 0;
}
#endif
#if 1
int CAN_Json_output( char * CAN_buffer, double battery_vol, char * ts)
{
    int k=0;
    //    uint8_t data[2000]={0};
    char temp_buff[500], battery[ 20 ];
    sprintf(CAN_buffer,"{\"ts\":\"%s\",\"imei\":%s\",\"type\":\"engine\"",ts,standard_cli.device_id);
#if 1
    for(k=0;k<PID_no;k++)
    {
        if(strstr(hApp->obdType_ht[k].Json_descript,"DTC") == NULL ){
            strcat(CAN_buffer,",");
            memset(temp_buff, 0 , sizeof(temp_buff));
            sprintf(temp_buff,"\"%s\":\"%ld\"",hApp->obdType_ht[k].Json_descript,hApp->CAN_ht[k].output);
            //            sprintf(temp_buff,"\"%s\":\"%f\"",hApp->obdType_ht[k].Json_descript,data->eng_coolant_temp);
            strcat(CAN_buffer,temp_buff);
        }
    }
#endif
    strcat(CAN_buffer,",");
    memset(battery, 0 , sizeof(battery));
    sprintf(battery,"\"bat_volt\":%lf",battery_vol);
    strcat(CAN_buffer,battery);
    strcat(CAN_buffer,"}");

    return 0;
}
#endif

#if 0
void send_data_to_cloud()
{
    int rc = 0;
    struct stat st;
    char *cmd;
    int ret = 0;
    DIR *d;
    FILE *fp;
    struct dirent *dir;
    char *str_check;
    char zip_file_bkp[2000]={0};
    char *cur_bkp_file_path;
    int i = 0;
    int len = 0;
    cmd = NULL;
    str_check = NULL;
    cur_bkp_file_path = NULL;
    memset(&st,0,sizeof(st));
    d = opendir(BKP_FOLDER);
    if (d)
    {
        while ((dir = readdir(d)) != NULL)
        {
            memset(bkp_file_name,0,sizeof(bkp_file_name));
            if(dir->d_name[0] != NULL)
            {
                len = 0;
                len = rc = strlen(dir->d_name);
                strncpy(bkp_file_name, dir->d_name,len+2);
                if((strstr(bkp_file_name, ".zip")) || (strstr(bkp_file_name, ".json")))
                {
                    printf("DEBUG : FILENAME BKP %s  %s L#%d \n",bkp_file_name,__func__, __LINE__);
                    bkp_count = bkp_count + 1;
                }
            }
        }
        memset(bkp_file_name,0,sizeof(bkp_file_name));
        str_check = NULL;
        if(d)
        {
            rc = closedir(d);
            d = NULL;
            dir = NULL;
        }
    }
    while(standard_cli.ready)
    {
        if(alert_bkp_count > 0)
        {
            //printf("DEBUG : alert_bkp_count %d data_file_ready %d  %s L#%d \n",alert_bkp_count ,data_file_ready,__func__, __LINE__);
            if(data_file_ready == 1)
            {
                memset(zip_file_bkp,0,sizeof(zip_file_bkp));
                if(file_name_zip[0] != NULL)
                {
                    len = 0;
                    len = rc = strlen(file_name_zip);
                    strncpy(zip_file_bkp,file_name_zip,len+2);
                    rc = asprintf(&cmd,"mv %s %s\n",zip_file_bkp,BKP_FOLDER);
                    rc = system(cmd);
                    system("sync");
                    sleep(1);
                    if(cmd)
                    {
                        free(cmd);
                        cmd = NULL;
                        if (malloc_trim(0) == 0)
                        {
                            printf("DEBUG : Failed to de-allocate memory  %s L#%d\n ", __func__, __LINE__);
                        }
                    }
                    bkp_count = bkp_count + 1;
                    data_file_ready = 0;
                    memset(file_name_zip,0,sizeof(file_name_zip));
                }
            }
            alert_ready = 1;
            memset(zip_file_bkp,0,sizeof(zip_file_bkp));
            if(bkp_alert_file_name_json[i] != NULL)
            {
                rc = strcpy(zip_file_bkp,bkp_alert_file_name_json[i]);
                memset(&st,0,sizeof(st));
                stat(zip_file_bkp, &st);
                alert_size = 0;
                alert_size = st.st_size;
                if(alert_size > 0)
                {
                    fp = fopen(zip_file_bkp, "r");
                    memset(alert_test_buffer, '\0' , sizeof(alert_test_buffer));
                    if(fp != NULL)
                    {
                        rc = fread(alert_test_buffer, 1, alert_size, fp);
                        if(rc <= 0)
                        {
                            printf("DEBUG : fread failed %d %s L#%d\n ",rc, __func__, __LINE__);
                        }
                        if(fp)
                        {
                            ret = fclose(fp);
                            if(ret != 0)
                            {
                                printf("DEBUG : fclose failed %d %s L#%d\n ",ret, __func__, __LINE__);
                            }
                            fp = 0;
                        }
                    }
                    if(rc > 0)
                    {
                        alert_send_ready = 1;
                        if(standard_cli.con_status == 1)
                        {
                            if(standard_cli.cloud_status == -1)
                            {
                                if(device_ll_handle != NULL)
                                {
                                    IoTHubDeviceClient_LL_Destroy(device_ll_handle);
                                    IoTHub_Deinit();
                                    device_ll_handle = NULL;
                                }
                                cloud_init();
                            }
                            if (IoTHubDeviceClient_LL_UploadMultipleBlocksToBlob(device_ll_handle, zip_file_bkp, getDataCallback, NULL) != IOTHUB_CLIENT_OK)
                            {
                                printf("Alert : Failed to send %s\n",zip_file_bkp);
                            }
                            else
                            {
                                printf("Alert : Successfully sent %s\n",zip_file_bkp);
                                len = 0;
                                len = strlen(zip_file_bkp) + strlen(CURR_FOLDER);
                                rc = asprintf(&cmd,"mv %s %s",zip_file_bkp,CURR_FOLDER);
                                system(cmd);
                                system("sync");
                                sleep(1);
                                if(cmd)
                                {
                                    free(cmd);
                                    cmd = NULL;
                                    if (malloc_trim(0) == 0)
                                    {
                                        printf("DEBUG : Failed to de-allocate memory  %s L#%d\n ", __func__, __LINE__);
                                    }
                                }
                                curr_count = curr_count + 1;
                                alert_bkp_count = alert_bkp_count - 1;
                                if(bkp_alert_file_name_json[i])
                                {
                                    free(bkp_alert_file_name_json[i]);
                                    bkp_alert_file_name_json[i] = NULL;
                                    if (malloc_trim(0) == 0)
                                    {
                                        printf("DEBUG : Failed to de-allocate memory  %s L#%d\n ", __func__, __LINE__);
                                    }
                                }
                                i = i+1;
                                if(alert_bkp_count == 0)
                                {
                                    i = 0;
                                    alert_file_read_ptr = 0;
                                    alert_ready = 0;
                                    bkp_send_stop = 0;
                                }
                            }
                            sleep(1);
                        }
                    }
                }
            }
        }
        else
        {
            if(data_file_ready == 1)
            {
                printf("DEBUG : data_file_ready %d BKP COUNT %d  alert_bkp_count  %d  bkp_send_ready %d bkp_send_stop %d %s L#%d\n",data_file_ready,bkp_count,alert_bkp_count,bkp_send_ready,bkp_send_stop,__func__, __LINE__);
                if(alert_bkp_count > 0)	
                {
                    memset(zip_file_bkp,0,sizeof(zip_file_bkp));
                    if(file_name_zip[0] != NULL)
                    {
                        len = 0;
                        len = rc = strlen(file_name_zip);
                        strncpy(zip_file_bkp,file_name_zip,len+1);
                        len = strlen(zip_file_bkp) + strlen(BKP_FOLDER);
                        rc = asprintf(&cmd,"mv %s %s\n",zip_file_bkp,BKP_FOLDER);
                        rc = system(cmd);
                        system("sync");
                        sleep(1);
                        if(cmd)
                        {
                            free(cmd);
                            cmd = NULL;
                            if (malloc_trim(0) == 0)
                            {
                                printf("DEBUG : Failed to de-allocate memory  %s L#%d\n ", __func__, __LINE__);
                            }
                        }
                        bkp_count = bkp_count + 1;	
                    }
                    memset(file_name_zip,0,sizeof(file_name_zip));
                }
                else
                {
                    if (standard_cli.con_status == -1)
                    {
                        len = strlen(file_name_zip) + strlen(BKP_FOLDER);
                        rc = asprintf(&cmd,"mv %s %s",file_name_zip,BKP_FOLDER);
                        bkp_count = bkp_count + 1;
                        rc = system(cmd);
                        system("sync");
                        sleep(1);
                        if(cmd)
                        {
                            free(cmd);
                            cmd = NULL;
                            if (malloc_trim(0) == 0)
                            {
                                printf("DEBUG : Failed to de-allocate memory  %s L#%d\n ", __func__, __LINE__);
                            }
                        }
                        bkp_send_stop = 0;
                    }
                    else if(standard_cli.con_status == 1)
                    {
                        memset(zip_file_bkp,0,sizeof(zip_file_bkp));
                        if(file_name_zip[0] != NULL)
                        {
                            len = strlen(file_name_zip);
                            strncpy(zip_file_bkp,file_name_zip,len+1);
                            rc = stat(zip_file_bkp, &st);
                            size1 = st.st_size;
                            if(size1 > 0)
                            {
                                fp = fopen(zip_file_bkp, "r");
                                if(fp != NULL)
                                {
                                    memset(test_buffer, '\0' , sizeof(test_buffer));
                                    rc = fread(test_buffer, 1, size1, fp);
                                    if(rc <= 0)
                                    {
                                        printf("DEBUG : fread failed %d %s L#%d\n ",rc, __func__, __LINE__);
                                    }
                                    if(fp)
                                    {
                                        ret = fclose(fp);
                                        if(ret != 0)
                                        {
                                            printf("DEBUG : fclose failed %d %s L#%d\n ",ret, __func__, __LINE__);
                                        }
                                        fp = 0;
                                    }
                                }
                                if(rc > 0)
                                {
                                    block_count =0;
                                    curr_send_status = 1;
                                    if(standard_cli.cloud_status == -1)
                                    {
                                        if(device_ll_handle != NULL)
                                        {
                                            IoTHubDeviceClient_LL_Destroy(device_ll_handle);
                                            IoTHub_Deinit();
                                            device_ll_handle = NULL;
                                        }
                                        cloud_init();
                                    }
                                    if (IoTHubDeviceClient_LL_UploadMultipleBlocksToBlob(device_ll_handle, zip_file_bkp, getDataCallback, NULL) != IOTHUB_CLIENT_OK)
                                    {
                                        printf("Failed to send %s\n",zip_file_bkp);
                                        len = 0;
                                        len = strlen(zip_file_bkp) + strlen(BKP_FOLDER);
                                        rc = asprintf(&cmd,"mv %s %s",zip_file_bkp,BKP_FOLDER);
                                        system(cmd);
                                        system("sync");
                                        sleep(1);
                                        if(cmd)
                                        {
                                            free(cmd);
                                            cmd = NULL;
                                            if (malloc_trim(0) == 0)
                                            {
                                                printf("DEBUG : Failed to de-allocate memory  %s L#%d\n ", __func__, __LINE__);
                                            }
                                        }
                                        bkp_count = bkp_count + 1;
                                        memset(bkp_file_name,0,sizeof(bkp_file_name));
                                        str_check = NULL;
                                        d = opendir("/iwtest/Application");
                                        if (d)
                                        {
                                            while ((dir = readdir(d)) != NULL)
                                            {
                                                if(data_file_ready == 1 || alert_bkp_count > 0)
                                                {
                                                    break;
                                                }
                                                memset(bkp_file_name,0,sizeof(bkp_file_name));
                                                if(dir->d_name[0] != NULL)
                                                {
                                                    len = strlen(dir->d_name);
                                                    strncpy(bkp_file_name, dir->d_name,len+1);
                                                    str_check = strstr(bkp_file_name, ".zip");
                                                    if(str_check)
                                                    {
                                                        rc = strcmp(file_name_zip,bkp_file_name);
                                                        if(rc != 0)
                                                        {
                                                            len = 0;
                                                            len = strlen(bkp_file_name) + strlen(BKP_FOLDER);
                                                            rc = asprintf(&cmd,"mv %s %s",bkp_file_name,BKP_FOLDER);
                                                            system(cmd);
                                                            system("sync");
                                                            sleep(1);
                                                            if(cmd)
                                                            {
                                                                free(cmd);
                                                                cmd = NULL;
                                                                if (malloc_trim(0) == 0)
                                                                {
                                                                    printf("DEBUG : Failed to de-allocate memory  %s L#%d\n ", __func__, __LINE__);
                                                                }
                                                            }
                                                            bkp_count = bkp_count + 1;
                                                        }
                                                    }
                                                }
                                            }
                                            if(d)
                                            {
                                                rc = closedir(d);
                                                d = NULL;
                                                dir = NULL;
                                            }
                                        }
                                        curr_send_status = 0;
                                    }
                                    else
                                    {
                                        printf("Successfully sent %s\n",zip_file_bkp);
                                        len = 0;
                                        len = strlen(zip_file_bkp) + strlen(CURR_FOLDER);
                                        rc = asprintf(&cmd,"mv %s %s",zip_file_bkp,CURR_FOLDER);
                                        system(cmd);
                                        system("sync");
                                        sleep(1);
                                        if(cmd)
                                        {
                                            free(cmd);
                                            cmd = NULL;
                                            if (malloc_trim(0) == 0)
                                            {
                                                printf("DEBUG : Failed to de-allocate memory  %s L#%d\n ", __func__, __LINE__);
                                            }
                                        }
                                        curr_count = curr_count + 1;
                                        bkp_send_ready = 0;
                                        curr_send_status = 0;
                                    }
                                    bkp_send_stop = 0;
                                    memset(file_name_zip,0,sizeof(file_name_zip));
                                }
                            }
                        }
                    }
                }
                data_file_ready = 0;
            }
            else
            {
                memset(bkp_file_name,0,sizeof(bkp_file_name));
                str_check = NULL;
                //printf("DEBUG : BKP COUNT %d  alert_bkp_count  %d  bkp_send_ready %d bkp_send_stop %d %s L#%d\n ",bkp_count,alert_bkp_count,bkp_send_ready,bkp_send_stop, __func__, __LINE__);
                if(bkp_count > 0 && alert_bkp_count == 0)
                {
                    if(standard_cli.con_status == 1)
                    {
                        d = opendir(BKP_FOLDER);
                        if (d)
                        {
                            while ((dir = readdir(d)) != NULL)
                            {
                                if(data_file_ready == 1 || bkp_count == 0 || bkp_send_stop == 1 || alert_bkp_count > 0)
                                {
                                    break;
                                }
                                if(bkp_send_ready == 1 && alert_bkp_count == 0)
                                {
                                    memset(bkp_file_name,0,sizeof(bkp_file_name));
                                    if(dir->d_name[0] != NULL)
                                    {
                                        len = 0;
                                        len = strlen(dir->d_name);
                                        strncpy(bkp_file_name, dir->d_name,len+2);
                                        if((strstr(bkp_file_name, ".zip")) || (strstr(bkp_file_name, ".json")))
                                        {
                                            printf("DEBUG : BKP FILENAME %s  %s L#%d\n ", bkp_file_name,__func__, __LINE__);		
                                            rc = asprintf(&cur_bkp_file_path,"%s/%s",BKP_FOLDER,bkp_file_name);
                                            memset(&st,0,sizeof(st));
                                            stat(cur_bkp_file_path, &st);
                                            size2 = (uint32_t) st.st_size;
                                            printf("DEBUG : Size of BKP FILE %d  %s L#%d\n ", size2,__func__, __LINE__);
                                            if(size2 > 0)
                                            {
                                                fp = fopen(cur_bkp_file_path, "r");
                                                memset(test_buffer_bkp, '\0' , sizeof(test_buffer_bkp));
                                                if(fp != NULL)
                                                {
                                                    rc = fread(test_buffer_bkp, 1, size2, fp);
                                                    if(rc <= 0)
                                                    {
                                                        printf("DEBUG : fread failed %d %s L#%d\n ",rc, __func__, __LINE__);
                                                    }
                                                    if(fp)
                                                    {
                                                        ret = fclose(fp);
                                                        if(ret != 0)
                                                        {
                                                            printf("DEBUG : fclose failed %d %s L#%d\n ",ret, __func__, __LINE__);
                                                        }
                                                        fp = 0;
                                                    }
                                                    if(rc > 0)
                                                    {
                                                        send_status_bkp = 1;
                                                        if (IoTHubDeviceClient_LL_UploadMultipleBlocksToBlob(device_ll_handle, bkp_file_name, getDataCallback, NULL) == IOTHUB_CLIENT_OK)
                                                        {
                                                            printf("BKP - Successfully sent %s\n",cur_bkp_file_path);
                                                            len = 0;
                                                            len = strlen(cur_bkp_file_path) + strlen(CURR_FOLDER);
                                                            rc = asprintf(&cmd,"mv %s %s",cur_bkp_file_path,CURR_FOLDER);
                                                            system(cmd);
                                                            system("sync");
                                                            sleep(1);
                                                            if(cmd)
                                                            {
                                                                free(cmd);
                                                                cmd = NULL;
                                                                if (malloc_trim(0) == 0)
                                                                {
                                                                    printf("DEBUG : Failed to de-allocate memory  %s L#%d\n ", __func__, __LINE__);
                                                                }
                                                            }
                                                            curr_count = curr_count + 1;
                                                            bkp_count = bkp_count -1;
                                                            bkp_send_ready = 0;
                                                            bkp_timer = 0;
                                                        }
                                                        if(cur_bkp_file_path)
                                                        {
                                                            free(cur_bkp_file_path);
                                                            cur_bkp_file_path = NULL;
                                                            if (malloc_trim(0) == 0)
                                                            {
                                                                printf("DEBUG : Failed to de-allocate memory  %s L#%d\n ", __func__, __LINE__);
                                                            }
                                                        }
                                                    }
                                                }
                                            }
                                            else
                                            {
                                                rc = asprintf(&cmd,"rm %s",cur_bkp_file_path);
                                                system(cmd);
                                                system("sync");
                                                sleep(1);
                                                if(cmd)
                                                {
                                                    free(cmd);
                                                    cmd = NULL;
                                                    if (malloc_trim(0) == 0)
                                                    {
                                                        printf("DEBUG : Failed to de-allocate memory  %s L#%d\n ", __func__, __LINE__);
                                                    }
                                                }
                                                bkp_count = bkp_count -1;
                                            }
                                        }
                                    }
                                }
                            }
                            closedir(d);	
                        }
                    }
                    usleep(250000);
                }
            }
        }
        if(bkp_count >= 400)
        {
            len = 0;
            len = strlen(BKP_FOLDER);
            asprintf(&cmd,"rm %s/* ",BKP_FOLDER);
            system(cmd);
            system("sync");
            if(cmd)
            {
                free(cmd);
                cmd = NULL;
                if (malloc_trim(0) == 0)
                {
                    printf("DEBUG : Failed to de-allocate memory  %s L#%d\n ", __func__, __LINE__);
                }
            }
            bkp_count = 0;
        }
        if(curr_count >= 200)
        {
            len = 0;
            len = strlen(CURR_FOLDER);
            asprintf(&cmd,"rm %s/* ",CURR_FOLDER);
            system(cmd);
            system("sync");
            if(cmd)
            {
                free(cmd);
                cmd = NULL;
                if (malloc_trim(0) == 0)
                {
                    printf("DEBUG : Failed to de-allocate memory  %s L#%d\n ", __func__, __LINE__);
                }
            }
            curr_count = 0;
        }
    }
    return;
}
#endif
#if 1 
void process_pkts()
{
    int rc = E_SUCCESS;
    //    time_t t;
    //    struct tm tm;
    signal(SIGALRM, sigalrm_handler);
    //    char *eh_buff = NULL;
    //    char ts[50];
    //    double bat_volt = 0;
    //    int str_len = 0;
    alarm(1);
    if( can_thread_flag == 1 )
    {
        if(data_pkt_ready == 1)
        {
            //        printf("Decoded Value is %f\n***********************",de_value);
            //        memset(ts,0,sizeof(ts));
            //        obd_get_time(ts);
#if 0
            memset(buffer,0,sizeof(buffer));
            frame_pkt_in_json(buffer,ts,j1939_p.imei,j1939_p.mac_address,"SW_REL3.5",&j_dat);
#endif
#if 0
            check_adc_voltage(&bat_volt);
            memset(buffer,0,sizeof(buffer));
            CAN_Json_output(buffer, bat_volt, ts);
#endif
            printf("CAN Buffer value = %s \n",buffer);

            /*!< Send gps packet to cloud*/
            rc = send_data_to_ble(buffer);
            if(rc == E_FAILURE){
                printf("Sending data to BLE failed\n");
            }
            /*Send data to UDP port*/
            //        pthread_mutex_unlock(&can_lock);
            rc = send_to_UDP(buffer);
            if(rc == E_FAILURE){
                printf("Sending data to UDP failed\n");
            }
            //        memset(buffer,0,sizeof(buffer));
        }
    }
    else{
    }
    return;
}
#endif
void gps_thread(void)
{
    //	int rc = 0;
    int rc = E_SUCCESS;
    char ts[64] = {0};
    char buffer [200]= {0};
    if( gps_thread_flag == 1 )
    {
        while(!standard_cli.interrupt)
        {
            if(standard_cli.appSleep == APP_SLEEP){
                break;
            }
            //        if(standard_cli.gps_fd > 0)
            //        {
            memset(ts,0,sizeof(ts));
            obd_get_time(ts);
            rc = get_gps_data_wrapper(&standard_cli.g_gps);
            //            sleep(1);
            if(rc < E_SUCCESS)
            {
                printf("read_req_data failed!\n");
            }
            memset(buffer,0,sizeof(buffer));
            frame_gps_pkt_in_json (buffer, &standard_cli.g_gps.gps_rmc, ts);
            printf("Buffer value = %s ",buffer);
            send_data_to_ble(buffer);
            rc = send_to_UDP(buffer);
            if (rc == E_FAILURE)
                printf ("send_data_to_cloud failed\n");
            //        }
            sleep(1);
        }
    }
    else
    {
    }
    gps_thread_flag = 0;
    printf("gps_thread exit \n");
}

#if 0
void alert_handler()
{
    double voltage = 0;
    char alert_msg[256] = {0};
    char alert_type[256] = {0};
    char alert_description[256] = {0};
    char *alert_file_name;
    char *alert_file_name_json;
    FILE *fp;
    struct stat st;
    time_t t;
    struct tm tm;
    char ts[50];
    int rc = 0;
    int number = 0;
    int len = 0;
    alert_file_name = NULL;
    alert_file_name_json = NULL;
    while(standard_cli.ready)
    {
        memset(alert_msg,0,sizeof(alert_msg));
        memset(alert_type,0,sizeof(alert_type));
        memset(alert_description,0,sizeof(alert_description));
        if(standard_cli.network_status == 1)
        {
            strncpy(alert_type,"NETWORK DISCONNECTED",30);
            frame_alert_packet(alert_msg,ts,j1939_p.imei,alert_type,alert_description);
            send_to_ble = 1;
            send_data_to_ble(alert_msg);
            send_to_ble = 0;
        }
        memset(alert_msg,0,sizeof(alert_msg));
        memset(alert_type,0,sizeof(alert_type));
        memset(alert_description,0,sizeof(alert_description));
        if((standard_cli.can_status == -1 && standard_cli.can_alert_not_available == 0) || (standard_cli.can_status == 1 && standard_cli.can_alert_available == 0))
        {
            if(standard_cli.can_alert_not_available == 0 && standard_cli.can_status == -1)
            {
                standard_cli.can_alert_not_available = 1;
                strncpy(alert_type,"CAN_DATA_NOT_AVAILABLE",30);
            }
            if(standard_cli.can_alert_available == 0 && standard_cli.can_status == 1)
            {
                standard_cli.can_alert_available = 1;
                strncpy(alert_type,"CAN_DATA_AVAILABLE",30);
            }
        }	
        else
        {
            rc = check_adc_voltage(&voltage);
            printf("ADC VOLTAGE %f\n",voltage);
            if(rc == 0)
            {
                if(voltage >= 10)
                {
                    if(external_power_connected == 0)
                    {
                        external_power_connected = 1;
                        external_power_disconnected_send = 0;
                    }
                    external_power_disconnected = 0;
                    strncpy(alert_type,"EXTERNAL_POWER_AVAILABLE",30);
                }
                else
                {
                    if(external_power_disconnected == 0)
                    {
                        external_power_disconnected = 1;
                        external_power_connected_send = 0;
                    }
                    external_power_connected = 0;
                    strncpy(alert_type,"NO_EXTERNAL_POWER_AVAILABLE",35);
                    frame_alert_packet(alert_msg,ts,j1939_p.imei,alert_type,alert_description);
                    send_to_ble = 1;
                    send_data_to_ble(alert_msg);
                    send_to_ble = 0;
                }
            }
        }
        //printf("external_power_connected_send %d external_power_connected %d external_power_disconnected_send %d external_power_disconnected %d\n",external_power_connected_send,external_power_connected,external_power_disconnected_send,external_power_disconnected);
        if(((external_power_connected_send == 0) && (external_power_connected == 1)) || ((external_power_disconnected_send == 0) && (external_power_disconnected == 1)) || ((standard_cli.can_alert_available == 1) || (standard_cli.can_alert_not_available == 1)))
        {
            if (alert_file_name == NULL)
            {
                t = time(NULL);
                tm = *localtime(&t);
                tm.tm_mon = tm.tm_mon+1;
                tm.tm_year = tm.tm_year+1900;
                number = number + 1;
                if(number >= 2147483647)
                {
                    number = 1;
                }
                rc = asprintf(&alert_file_name,"%s_alert_%d_%d%d%d%d%d%d",standard_cli.dev_id,number,tm.tm_year,tm.tm_mon,tm.tm_mday,tm.tm_hour,tm.tm_min,tm.tm_sec);
                rc = asprintf(&alert_file_name_json, "%s.json", alert_file_name);
                memset(ts,0,sizeof(ts));
                rc = snprintf(ts,sizeof(ts),"%d%d%d%d%d",tm.tm_year,tm.tm_mon,tm.tm_mday,tm.tm_hour,tm.tm_min);
                memset(alert_msg,0,sizeof(alert_msg));
                frame_alert_packet(alert_msg,ts,j1939_p.imei,alert_type,alert_description);
                memset(&tm,0,sizeof(tm));
                memset(&t,0, sizeof(t));
                fp = fopen(alert_file_name_json, "a+");
                if(fp != NULL)
                {
                    rc = fputs("[",fp);
                    if(rc <= 0)
                    {
                        printf("DEBUG : fputs failed %d %s L#%d\n ",rc, __func__, __LINE__);
                    }
                    fseek(fp,0,SEEK_END);
                    rc = fputs(alert_msg,fp);
                    if(rc <= 0)
                    {
                        printf("DEBUG : fputs failed %d %s L#%d\n ",rc, __func__, __LINE__);
                    }
                    rc = fputs("]",fp);
                    if(rc <= 0)
                    {
                        printf("DEBUG : fputs failed %d %s L#%d\n ",rc, __func__, __LINE__);
                    }
                    sleep(1);
                    if(fp)
                    {
                        rc = fclose(fp);
                        if(rc != 0)
                        {
                            printf("DEBUG : fclose failed %d %s L#%d\n ",rc, __func__, __LINE__);
                        }
                        fp = 0;
                    }
                }
                send_to_ble = 1;
                send_data_to_ble(alert_msg);
                send_to_ble = 0;
                //printf("*************** alert_file_read_ptr %d\n",alert_file_read_ptr);
                bkp_alert_file_name_json[alert_file_read_ptr] = (char *)malloc(256);
                rc = strcpy(bkp_alert_file_name_json[alert_file_read_ptr],alert_file_name_json); 
                //printf("*************** bkp_alert_file_name_json[%d] %s\n",alert_file_read_ptr,bkp_alert_file_name_json[alert_file_read_ptr]);
                alert_bkp_count = alert_bkp_count + 1;
                alert_file_read_ptr = alert_file_read_ptr + 1;
                if((standard_cli.can_alert_not_available == 1) || (standard_cli.can_alert_available == 1))
                {
                    if(standard_cli.can_alert_not_available == 1)
                    {
                        standard_cli.can_alert_not_available  = -1;;
                    }
                    else if(standard_cli.can_alert_available == 1)
                    {
                        standard_cli.can_alert_available = -1;
                    }
                }
                else
                {
                    if(external_power_connected == 1)
                    {
                        external_power_connected_send = 1;
                    }
                    else if(external_power_disconnected == 1)
                    {
                        external_power_disconnected_send = 1;
                    }
                }
            }
            if(alert_file_name_json)
            {
                free(alert_file_name_json);
                alert_file_name_json = NULL;
                if (malloc_trim(0) == 0)
                {
                    printf("DEBUG : Failed to de-allocate memory  %s L#%d\n ", __func__, __LINE__);
                }
            }	
            if(alert_file_name_json)
            {
                free(alert_file_name_json);
                alert_file_name_json = NULL;
                if (malloc_trim(0) == 0)
                {
                    printf("DEBUG : Failed to de-allocate memory  %s L#%d\n ", __func__, __LINE__);
                }
            }	
            if(alert_file_name)
            {
                free(alert_file_name);
                alert_file_name = NULL;
                if (malloc_trim(0) == 0)
                {
                    printf("DEBUG : Failed to de-allocate memory  %s L#%d\n ", __func__, __LINE__);
                }
            }
        }
        sleep(1);
    }
}
#endif
#if 0
int frame_alert_packet(char *buffer,char *ts,char *device_id,char *type,char *description)
{
    printf("deviceId : %s,incDate : %s , type : %s , description : %s \n",device_id,ts,type,description);
    sprintf(buffer,"{\"deviceId\":\"%s\",\"incDate\":\"%s\",\"type\":\"%s\",\"description\":\"%s\"}\n",device_id,ts,type,description);
    return 0;
}
#endif
#if 0
int convert_existing_file()
{
    int rc = 0;
    int len = 0;
    DIR *d;
    struct dirent *dir;
    char *token = NULL;
    char *str_check = NULL;
    char *buff = NULL;
    struct stat st;
    FILE *fp,*tmp_fp;
    char *temp = NULL;
    char line[256]={0};
    char txt_file_name[500] = {0};
    int length = 0;
    char *check = NULL;
    char txt_file_name_bkp[500] = {0};
    char *zip_file_name = NULL;
    int count = 0;
    int line_number = 0; 
    char c;
    d = opendir("/iwtest/Application");
    if (d)
    {
        while ((dir = readdir(d)) != NULL)
        {
            memset(txt_file_name,0,sizeof(txt_file_name));
            memset(txt_file_name_bkp,0,sizeof(txt_file_name_bkp));
            if(dir->d_name[0] != NULL)
            {
                len = 0;
                len = strlen(dir->d_name);
                line_number = 0;
                count = 0;
                strncpy(txt_file_name, dir->d_name,len+2);
                strncpy(txt_file_name_bkp, dir->d_name,len+2);
                str_check = strstr(txt_file_name, ".txt");
                if(str_check)
                {
                    token = strtok(txt_file_name, ".");
                    rc = asprintf(&temp,"%s",token);
                    fp = fopen(txt_file_name_bkp, "a+");
                    if(fp != NULL)

                        memset(line,0,sizeof(line));
                    while(fgets(line, sizeof(line), fp) != NULL)
                    {
                        check = strstr(line,"{");
                        if(check)
                        {
                            line_number = line_number + 1;
                        }
                    }
                    memset(line,0,sizeof(line));
                    rewind(fp);
                    if(line_number <= 1)
                    {
                        rc = asprintf(&buff, "rm  %s", txt_file_name_bkp);
                        system(buff);
                        system("sync");
                        if(buff)
                        {
                            free(buff);
                            buff = NULL;
                            if (malloc_trim(0) == 0)
                            {
                                printf("DEBUG : Failed to de-allocate memory  %s L#%d\n ", __func__, __LINE__);
                            }
                        }
                        if(fp)
                        {
                            rc = fclose(fp);
                            if(rc != 0)
                            {
                                printf("DEBUG : fclose failed %d %s L#%d\n ",rc, __func__, __LINE__);
                            }
                            fp = 0;
                        }
                        if(tmp_fp)
                        {
                            rc = fclose(tmp_fp);
                            if(rc != 0)
                            {
                                printf("DEBUG : fclose failed %d %s L#%d\n ",rc, __func__, __LINE__);
                            }
                            tmp_fp = 0;
                        }
                    }
                    else
                    {
                        if(line_number > 1 && line_number < 600)
                        {
                            tmp_fp = fopen("sample.txt","a+");
                            if(tmp_fp != NULL)
                            {
                                while(fgets(line, sizeof(line), fp) != NULL)
                                {
                                    check = strstr(line,"{");
                                    if(check)
                                    {
                                        count = count + 1;
                                    }
                                    if(count >= line_number)
                                    {
                                        break;
                                    }
                                    else
                                    {
                                        rc = fputs(line,tmp_fp);
                                        if(rc <= 0)
                                        {
                                            printf("DEBUG : fputs failed %d %s L#%d\n ",rc, __func__, __LINE__);
                                        }
                                    }
                                }
                                fseek(tmp_fp,0,SEEK_END);
                                rc = fputs("]",tmp_fp);
                                if(rc <= 0)
                                {
                                    printf("DEBUG : fputs failed %d %s L#%d\n ",rc, __func__, __LINE__);
                                }
                            }
                            sleep(1);
                            rc = asprintf(&buff, "rm  %s", txt_file_name_bkp);
                            system(buff);
                            system("sync");
                            if(buff)
                            {
                                free(buff);
                                buff = NULL;
                                if (malloc_trim(0) == 0)
                                {
                                    printf("DEBUG : Failed to de-allocate memory  %s L#%d\n ", __func__, __LINE__);
                                }
                            }
                            rc = asprintf(&buff, "mv sample.txt %s", txt_file_name_bkp);
                            system(buff);
                            system("sync");
                            if(buff)
                            {
                                free(buff);
                                buff = NULL;
                                if (malloc_trim(0) == 0)
                                {
                                    printf("DEBUG : Failed to de-allocate memory  %s L#%d\n ", __func__, __LINE__);
                                }
                            }
                        }
                        if(fp)
                        {
                            rc = fclose(fp);
                            if(rc != 0)
                            {
                                printf("DEBUG : fclose failed %d %s L#%d\n ",rc, __func__, __LINE__);
                            }
                            fp = 0;
                        }
                        if(tmp_fp)
                        {
                            rc = fclose(tmp_fp);
                            if(rc != 0)
                            {
                                printf("DEBUG : fclose failed %d %s L#%d\n ",rc, __func__, __LINE__);
                            }
                            tmp_fp = 0;
                        }
                        rc = asprintf(&buff, "zip %s.zip %s", temp,txt_file_name_bkp);
                        system(buff);
                        system("sync");
                        if(buff)
                        {
                            free(buff);
                            buff = NULL;
                            if (malloc_trim(0) == 0)
                            {
                                printf("DEBUG : Failed to de-allocate memory  %s L#%d\n ", __func__, __LINE__);
                            }
                        }
                        rc = asprintf(&buff, "rm /iwtest/Application/%s",txt_file_name_bkp);
                        system(buff);
                        system("sync");
                        if(buff)
                        {
                            free(buff);
                            buff = NULL;
                            if (malloc_trim(0) == 0)
                            {
                                printf("DEBUG : Failed to de-allocate memory  %s L#%d\n ", __func__, __LINE__);
                            }
                        }
                        memset(txt_file_name,0,sizeof(txt_file_name));
                        rc = asprintf(&zip_file_name, "%s.zip", temp);
                        rc = asprintf(&buff, "mv %s %s", zip_file_name,BKP_FOLDER);
                        system(buff);
                        system("sync");
                        sleep(1);
                        if(buff)
                        {
                            free(buff);
                            buff = NULL;
                            if (malloc_trim(0) == 0)
                            {
                                printf("DEBUG : Failed to de-allocate memory  %s L#%d\n ", __func__, __LINE__);
                            }
                        }
                        if(temp)
                        {
                            free(temp);
                            temp = NULL;
                            if (malloc_trim(0) == 0)
                            {
                                printf("DEBUG : Failed to de-allocate memory  %s L#%d\n ", __func__, __LINE__);
                            }
                        }
                    }
                }
            }
            else
            {
                str_check = strstr(txt_file_name_bkp, ".json");
                if(str_check)
                {
                    rc = asprintf(&buff, "mv /iwtest/Application/%s %s", txt_file_name_bkp,BKP_FOLDER);
                    system(buff);
                    system("sync");
                    sleep(1);
                    if(buff)
                    {
                        free(buff);
                        buff = NULL;
                        if (malloc_trim(0) == 0)
                        {
                            printf("DEBUG : Failed to de-allocate memory  %s L#%d\n ", __func__, __LINE__);
                        }
                    }
                }
            }
        }
    }
    str_check = NULL;
    if(d)
    {
        rc = closedir(d);
        d = NULL;
        dir = NULL;
    }
}
return rc;
}
#endif
