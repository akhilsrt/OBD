#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <string.h>
#include <errornos.h>
#include <app.h>
#include <sys/time.h>
#include <time.h>
#include <pthread.h>
#include <unistd.h>
#include "iothub_client_ll_uploadtoblob.h"
#include <sys/stat.h>
#include "gsm.h"
#include "gps.h"
#include "common.h"
#define serv_port_down 1687

FILE *fp;
unsigned char const test_buffer[4098];
size_t size1;
//int recv_from = 0;

int main()
{
    int recv_from = 0;	
    int rc = 0;
    char device_id[100] = {0};
//    int ret = 0;
    char connection_String[200];
    int sockfd; /* socket */
    int clientlen; /* byte size of client's address */
    struct sockaddr_in serveraddr; /* server's addr */
    struct sockaddr_in clientaddr; /* client addr */
    //    struct hostent *hostp; /* client host info */
    //    char *hostaddrp; /* dotted decimal host addr string */
    int optval;
    int n;
    pthread_mutex_init( &lock, NULL );
    pthread_mutex_init( &udp_lock, NULL );
    pthread_mutex_init( &can_lock, NULL );

    standard_cli.con_status = -1;
    standard_cli.cloud_status = -1;
    standard_cli.can_status = -1;
    standard_cli.network_status = 0;
    standard_cli.can_alert_not_available = 0;
    standard_cli.can_alert_available = 0;
    device_ll_handle = NULL;
    printf("!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!! START !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!\n");
    //	rc = convert_existing_file();
    printf("Converted all existing files ---- rc %d\n",rc);
    rc = init(NULL, NULL);
    if(rc != 0)
    {
        printf("init() failed ---- rc %d\n",rc);
    }
    else
    {
        rc = check_gsm_modem_status();
        if(rc != 0)
        {
            /* Turning on the GSM modem */
            rc = gsm_modem_on();
            printf("gsm_modem_on() Return value = %d\n",rc);
        }
    }
    if(rc == E_SUCCESS)
    {
        rc = establish_network_connection();
        if(rc == 0)
        {
            standard_cli.con_status = 1;
        }
#if 0
        rc = agps_init();
        printf("quectel_agps_init() Return value = %d\n",rc);
        //		standard_cli.gps_fd = gps_init();
        //		printf("gps_init() Return value = %d\n",standard_cli.gps_fd);
#endif
    }
    rc = get_gsm_imei(device_id);
    if(rc == E_SUCCESS)
    {
        strcpy(standard_cli.device_id, device_id);
        printf("Device ID [%s]\n", standard_cli.device_id);
    }

    memset(connection_String, 0, sizeof(connection_String));
    memset(standard_cli.con_string,0,sizeof(standard_cli.con_string));
    //	read_cloud_config(connection_String);
    strcpy(standard_cli.con_string,connection_String);
    get_device_id(connection_String);
#if 0
    if(standard_cli.con_status == 1)
    {
        ntp_server_update();
        //	printf("CONNECTION STRING %s\n",connection_String);
        //	cloud_init();
    }
    else
    {
        standard_cli.cloud_status = -1;
    }
#endif


    sockfd = socket(AF_INET, SOCK_DGRAM, 0);
    if (sockfd < 0)
        printf("ERROR opening socket");
    optval = 1;
    setsockopt(sockfd, SOL_SOCKET, SO_REUSEADDR, (const void *) &optval,
            sizeof(int));

    memset(&serveraddr, 0, sizeof(serveraddr));
    serveraddr.sin_family = AF_INET;
    serveraddr.sin_addr.s_addr = htonl(INADDR_ANY);
    serveraddr.sin_port = htons(serv_port_down);

    if (bind(sockfd, (struct sockaddr *) &serveraddr, sizeof(serveraddr)) < 0)
        printf("ERROR on binding");
    standard_cli.gps_fd = gps_init();
    if (standard_cli.gps_fd == E_FAILURE)
    {
        printf("gps init faild\n");
    }

    acc_init();
    gyro_init();
    standard_cli.interrupt = 0;
//    PID_no = 0;

    memset(j1939_p.imei,0,sizeof(j1939_p.imei));
    get_gsm_imei(j1939_p.imei);
    standard_cli.ready = 0;
    memset(j1939_p.mac_address,0,sizeof(j1939_p.mac_address));
    get_mac_address("hci0",j1939_p.mac_address);
#if 0
    rc = j1939_can_init();
    printf("RC %d\n",rc);
    if(rc == E_SUCCESS)
    {
        standard_cli.can_status = 1;
    }
    else
    {
        standard_cli.can_status = -1;
    }
//    thread_init();
    if(standard_cli.can_status == -1)
    {
        while(1)
        {
            if(standard_cli.can_status  == -1)
            {
                rc = j1939_can_init();
                if(rc == 0)
                {
                    standard_cli.can_status = 1;
                    break;
                }
                sleep(60);
            }
        }
    }
#endif
#if 1
    PID_no = 0;
    while(1)
    {
        sleep(3);
        if(recv_from == 0){
            recv_from = 1;
            if(recv_from == 1){
                if (pthread_create(&(p_tid[6]), NULL, (void*) controller_function, NULL) != 0) {
                    rc = E_FAILURE;
                }
                else{
                    printf("controller_function is created\n");
                    if (pthread_detach((p_tid[6])) == 0)
                    {   
                        printf("Controller Function Thread detached successfully %d\n",errno);
                    }
                }
            }
        }
    
#endif
#if 1
        /*
         * recvfrom: receive a UDP datagram from a client
         */

        memset(buf, 0, BUFSIZE);
        n = recvfrom(sockfd, buf, BUFSIZE, 0, (struct sockaddr *) &clientaddr,
                (socklen_t *) &clientlen); /*Receive adta from udp client*/
        if (n < 0)
            printf("ERROR in recvfrom");
        if (n == 0) {
            usleep(500); /*wait some time*/
            continue;
        }
        printf("%s\r\n",buf);
        printf("Before CAN_LOCK in while*************\n");
        pthread_mutex_lock(&udp_lock);
        printf("After CAN_LOCK in while*************\n");
        parse_configuration(buf);
        file_set_flag = 0;
        printf("Before CAN_UNLOCK in while*************\n");
        pthread_mutex_unlock(&udp_lock);
        printf("After CAN_UNLOCK in while*************\n");
    }
#endif
    pthread_join((p_tid[0]), NULL);
    gsm_modem_off();
    j1939_can_deinit();
    //	IoTHubDeviceClient_LL_Destroy(device_ll_handle);
    //	IoTHub_Deinit();
    device_ll_handle = NULL;
    return 0;
}
int establish_network_connection()
{
    int ret = 0;
    int time_diff = E_SUCCESS;
    struct timespec start, end;
    int network_mode = 4;
    int current_mode = 0;
    memset(&start,0,sizeof(start));
    memset(&start,0,sizeof(end));
    clock_gettime(CLOCK_MONOTONIC, &start);
    ret = get_gsm_sim_status();
    if(ret == 0)
    {
        ret = get_network_mode(&current_mode);
        printf("get_network_mode() ret %d Current Network Mode %d\n",ret,current_mode);
        printf("SIM is inserted\n");
        while(1)
        {
            ret = check_gsm_nw_connection();
            if (ret == 0)
            {
                ret = 0;
                printf("Connection Established Successfully\n");
                standard_cli.con_status = 1;
                break;
            }
            else
            {
                printf("**trying to connect\n");				
                establish_connection();
                sleep(2);
            }
            usleep (1000000);
            clock_gettime(CLOCK_MONOTONIC, &end);
            time_diff = time_diff_seconds(&end, &start);
            if(time_diff >= 60)
            {
set_mode:
                if(network_mode <= 0)
                {
                    ret = -1;
                    system("poff");
                    system("killall -9 pppd");
                    break;
                }
                ret = set_gsm_network_mode(network_mode);
                printf("set_gsm_network_mode() ret %d Mode %d\n",ret,network_mode);
                network_mode = network_mode - 1;
                if(ret == 0)
                {
                    memset(&start,0,sizeof(start));
                    memset(&start,0,sizeof(end));
                    clock_gettime(CLOCK_MONOTONIC, &start);
                    system("poff");
                    system("killall -9 pppd");
                    time_diff = 0;
                    continue;
                }
                else
                {
                    goto set_mode;
                }
            }
        }
    }
    return ret;
}
int time_diff_seconds(struct timespec *time_end, struct timespec *time_start)
{
    int ret = 0;
    ret = time_end->tv_sec - time_start->tv_sec;
    return ret;
}
int time_diff_nano_seconds(struct timespec *time_end, struct timespec *time_start)
{
    int ret = 0;
    ret = time_end->tv_nsec - time_start->tv_nsec;
    return ret;
}
#if 0
int read_cloud_config (char *connection_String)
{
    int rc = 0 ;
    printf("read_cloud_config ++\n");
    rc = get_xml_content(SRC_XML_FILE, PARENT_NODE_CLOUD, "con_string", connection_String);
    if (rc < 0){
        printf ("get_xml_content sas_token failed\n");
    }
    else
    {
        puts(connection_String);
    }
    printf("read_cloud_config -- rc\n");
    return rc;
}
#endif
int get_device_id(char *con_string)
{
    char str[256] = {0};
    char* token;
    char temp[240] ={0};
    memset(str,0,sizeof(str));
    memset(temp,0,sizeof(temp));
    memset(standard_cli.dev_id,0,sizeof(standard_cli.dev_id));
    strcpy(str,con_string);
    printf("con_string %s\n",str);
    token = strtok(str, ";");
    while (token != NULL)
    {
        printf("%s\n", token);
        if(strstr(token,"DeviceId"))
        {
            strcpy(temp,token);
            printf("%s\n", temp);
            token = NULL;
            break;
        }
        token = strtok(NULL, ";");
    }
    token = strtok(temp, "=");
    while (token != NULL)
    {
        printf("%s\n", token);
        strcpy(standard_cli.dev_id,token);
        if(token == NULL)
        {
            token = NULL;
            break;
        }
        token = strtok(NULL,"=");
    }
    printf("DEVICE ID %s\n",standard_cli.dev_id);
    return 0;
}
#if 0
void cloud_init()
{
    (void)IoTHub_Init();
    (void)printf("Starting the IoTHub client sample upload to blob with multiple blocks...\r\n");
    device_ll_handle = IoTHubDeviceClient_LL_CreateFromConnectionString(standard_cli.con_string, HTTP_Protocol);
    if (device_ll_handle == NULL)
    {
        (void)printf("Failure creating IotHub device. Hint: Check your connection string.\r\n");
    }
    else
    {
#ifndef WIN32
        size_t log = 1;
        (void)IoTHubDeviceClient_LL_SetOption(device_ll_handle, OPTION_CURL_VERBOSE, &log);
#endif // !WIN32

#ifdef SET_TRUSTED_CERT_IN_SAMPLES
        // Setting the Trusted Certificate. This is only necessary on systems without
        // built in certificate stores.
        IoTHubDeviceClient_LL_SetOption(device_ll_handle, OPTION_TRUSTED_CERT, certificates);
#endif // SET_TRUSTED_CERT_IN_SAMPLES

        HTTP_PROXY_OPTIONS http_proxy_options = { 0 };
        http_proxy_options.host_address = proxyHost;
        http_proxy_options.port = proxyPort;



        if (proxyHost != NULL && IoTHubDeviceClient_LL_SetOption(device_ll_handle, OPTION_HTTP_PROXY, &http_proxy_options) != IOTHUB_CLIENT_OK)
        {
            (void)printf("failure to set proxy\n");
        }
        else
        {
            standard_cli.cloud_status = 1;
        }
    }
}
#endif
