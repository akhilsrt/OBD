#include<stdio.h>
typedef struct DTC
{
        int mil_status;
        int rsl_status;
        int awl_status;
        int pl_status;
        unsigned long int spn;
        int fmi;
}dtc_dat;
typedef struct j1939_data
{
        char description[100];
        char unit[100];
        double value;
        char state[100];
        unsigned long int pgn;
        int spn;
        unsigned long int spn_id;
        char vin[256];
        char driver1_id[256];
        char driver2_id[256];
}j1939_data;
int j1939_recv_broadcast_response(uint8_t *ar_brd_cast_resp, int *len,unsigned long int *pgn);
//int get_spn_no(unsigned long int pgn,int * spn_count);
j1939_data *j1939_decode_data(uint8_t *ar_raw_data, int len, unsigned long int pgn,int spnCount);
int j1939_decode_messages(uint8_t *ar_raw_data, int len, unsigned long int pgn,j1939_data **j_dat);
