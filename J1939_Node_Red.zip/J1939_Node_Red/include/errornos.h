#ifndef __J1939_STACK_ERR_H_
#define __J1939_STACK_ERR_H_

//#define ENABLE_IOBD_DEBUG_LEVEL
#ifdef ENABLE_IOBD_DEBUG_LEVEL
#define IOBD_DEBUG_LEVEL(...)\
{\
        printf("DEBUG:   %s L#%d ", __func__, __LINE__);  \
        printf(__VA_ARGS__); \
        printf("\n"); \
}
#else
#define IOBD_DEBUG_LEVEL(...)
#endif

//#define ENABLE_IOBD_DEBUG_LEVEL5
#ifdef ENABLE_IOBD_DEBUG_LEVEL5
#define IOBD_DEBUG_LEVEL5(...)\
{\
        printf("DEBUG:   %s L#%d ", __func__, __LINE__);  \
        printf(__VA_ARGS__); \
        printf("\n"); \
}
#else
#define IOBD_DEBUG_LEVEL5(...)
#endif

//#define ENABLE_IOBD_DEBUG_LEVEL1
#ifdef ENABLE_IOBD_DEBUG_LEVEL1
#define IOBD_DEBUG_LEVEL1(...)\
{\
        printf("DEBUG:   %s L#%d ", __func__, __LINE__);  \
        printf(__VA_ARGS__); \
        printf("\n"); \
}
#else
#define IOBD_DEBUG_LEVEL1(...)
#endif

//#define ENABLE_IOBD_DEBUG_LEVEL2
#ifdef ENABLE_IOBD_DEBUG_LEVEL2
#define IOBD_DEBUG_LEVEL2(...)\
{\
        printf("DECODE:   %s L#%d ", __func__, __LINE__);  \
        printf(__VA_ARGS__); \
        printf("\n"); \
}
#else
#define IOBD_DEBUG_LEVEL2(...)
#endif
/*
 * Message Queue Related Error
*/
#define MQ_ERROR                                        (0xB0)
#define MQ_ERROR_BASE                                   (MQ_ERROR * E_FAILURE)
#define MQ_OPEN_ERR                                     (MQ_ERROR_BASE + 1)
#define MQ_UNLINK_ERR                                   (MQ_ERROR_BASE + 2)
#define MQ_SEND_ERR                                     (MQ_ERROR_BASE + 3)
#define MQ_WRITE_ERR                                    (MQ_ERROR_BASE + 4)
#define E_SUCCESS                                       (0)
#define E_FAILURE                                       (-1)
#define PGN_PTO						64932
/*
 * C Library Function Errors
 */
#define LIB_API_ERROR					(0xFD0)
#define LIB_API_ERROR_BASE				(LIB_API_ERROR * E_FAILURE)
#define PTHREAD_CREATE_ERR				(LIB_API_ERROR_BASE + 1)	
#define SOCKET_CREATE_ERR				(LIB_API_ERROR_BASE + 2)
#define SET_SOCKOPT_ERR					(LIB_API_ERROR_BASE + 3)
#define SOCKET_BIND_ERR					(LIB_API_ERROR_BASE + 4)
#define SOCKET_CLOSE_ERR				(LIB_API_ERROR_BASE + 5)
#define SEM_INIT_ERR					(LIB_API_ERROR_BASE + 6)
#define FILE_OPEN_ERR					(LIB_API_ERROR_BASE + 7)
#define FILE_READ_ERR					(LIB_API_ERROR_BASE + 8)
#define MEMSET_ERR					(LIB_API_ERROR_BASE + 9)
#define STRCPY_ERR					(LIB_API_ERROR_BASE + 10)
#define SPRINTF_ERR					(LIB_API_ERROR_BASE + 11)
#define FCLOSE_ERR					(LIB_API_ERROR_BASE + 12)

/*
 * J1939 Stack Libarary Errors
 */
#define E_J1939_STACK_ERR		        	(0xFF0)
#define E_J1939_STACK_ERR_BASE				(E_J1939_STACK_ERR * E_FAILURE)
#define E_J1939_STACK_CAN_INIT_ERR			(E_J1939_STACK_ERR_BASE + 1)
#define E_J1939_STACK_THREAD_INIT_ERR			(E_J1939_STACK_ERR_BASE + 2)
#define E_J1939_STACK_CAN_DEINIT_ERR			(E_J1939_STACK_ERR_BASE + 3)
#define E_J1939_STACK_GET_CLOCK_TIME_ERR		(E_J1939_STACK_ERR_BASE	+ 4)
#define E_J1939_STACK_RECV_TIMEOUT_ERR			(E_J1939_STACK_ERR_BASE + 5)
#define E_J1939_STACK_NO_RESPONSE			(E_J1939_STACK_ERR_BASE + 6)
#define E_J1939_STACK_INVALID_DATA			(E_J1939_STACK_ERR_BASE + 7)
#define E_J1939_STACK_PGN_NOT_SUPPORTED			(E_J1939_STACK_ERR_BASE + 8)
#define E_J1939_STACK_ACCESS_DENIED			(E_J1939_STACK_ERR_BASE + 9)
#define E_J1939_STACK_CANNOT_RESPOND			(E_J1939_STACK_ERR_BASE + 10)
#define E_J1939_STACK_REQUEST_SEND_ERR			(E_J1939_STACK_ERR_BASE + 11)
#define E_J1939_STACK_REQ_MSG_LIMIT_EXCEEDED            (E_J1939_STACK_ERR_BASE + 12)
/*
 * Sample DBC File Read and Parse Errors
 */
#define E_J1939_SAMPLE_DBC_ERR				(0xFE0)
#define E_J1939_SAMPLE_DBC_ERR_BASE			(E_J1939_SAMPLE_DBC_ERR * E_FAILURE)
#define E_J1939_SAMPLE_DBC_NO_DATA_FOUND		(E_J1939_SAMPLE_DBC_ERR_BASE + 1)
#define E_J1939_SAMPLE_DBC_INVALID_DATA			(E_J1939_SAMPLE_DBC_ERR_BASE + 2)

/*
 * Hard Decoding Without XML
 */
#define E_J1939_STACK_DECODE		        	(0xFF0)
#define E_J1939_STACK_DECODE_BASE			(E_J1939_STACK_DECODE * E_FAILURE)
#define E_CLUTCH_SWITCH_PEDAL_RELEASED			(E_J1939_STACK_DECODE + 1)
#define E_CLUTCH_SWITCH_PEDAL_DEPRESSED			(E_J1939_STACK_DECODE + 2)
#define E_BREAK_SWITCH_PEDAL_RELEASED			(E_J1939_STACK_DECODE + 3)
#define E_BREAK_SWITCH_PEDAL_DEPRESSED			(E_J1939_STACK_DECODE + 4)
#define E_CRUICE_CNTRL_OFF				(E_J1939_STACK_DECODE + 5)
#define E_CRUICE_CNTRL_ON				(E_J1939_STACK_DECODE + 6)
#define E_PTO_DISABLED					(E_J1939_STACK_DECODE + 7)
#define E_PTO_ACTIVE					(E_J1939_STACK_DECODE + 8)
#define E_PTO_NOT_AVAILABLE				(E_J1939_STACK_DECODE + 9)
#define E_J1939_STACK_INVALID_PGN			(E_J1939_STACK_DECODE + 10)
#define E_DRIVER_CARD_1_NOT_PRESENT			(E_J1939_STACK_DECODE + 11)
#define E_DRIVER_CARD_2_NOT_PRESENT                     (E_J1939_STACK_DECODE + 12)
#define E_NO_DRIVER_CARDS_PRESENT			(E_J1939_STACK_DECODE + 13)
#define E_DRIVER_CARD_1_PRESENT				(E_J1939_STACK_DECODE + 15)
#define E_DRIVER_CARD_2_PRESENT				(E_J1939_STACK_DECODE + 16)

#define E_DRIVER_IN_REST				0
#define E_DRIVER_WORK					2				
#define E_DRIVER_DRIVE					3
#define E_DRIVER_AVAILABLE				1
#define E_DRIVER_ERROR					6
#define E_DRIVER_NOT_AVAILABLE				7

#define E_DRIVER_REL_STATE_NORMAL			0
#define E_DRIVER_REL_STATE_15MINS_TO_4_HALF_HRS		1	
#define E_DRIVER_REL_STATE_REACHED_4_HALF_HRS		2
#define E_DRIVER_REL_STATE_15MINS_BEFORE_9HRS		3
#define E_DRIVER_REL_STATE_REACHED_9HRS			4
#define E_DRIVER_REL_STATE_15MINS_BEFORE_16HRS		5
#define E_DRIVER_REL_STATE_REACHED_16HRS		6
#define E_DRIVER_REL_STATE_ERR				14
#define E_DRIVER_REL_STATE_NOT_AVAILABLE		15
#endif
