#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <string.h>
#include <signal.h>
#include <errornos.h>
#include "app.h"
#include <sys/time.h>
#include <arpa/inet.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <sys/stat.h>
#include <unistd.h>
#include <time.h>
#include "common.h"
#include "gps.h"
#include "gsm.h"
#include <pthread.h>

#define serv_port_up 1688

int modem_reset_count = 0;
void reset_network_connection()
{
	int rc = 0;
	int start_loop = 0;
	int start_check = 0;
	int time_diff = 0;
	int pppd_reset_1 = 0;
	int pppd_reset_2 = 0;
	int pppd_reset_3 = 0;
	struct timespec start, end;
	memset(&end,0,sizeof(end));
	memset(&start,0,sizeof(start));
	time_diff = 0;
	printf("reset_network_connection () ++\n");
    if( reset_connection_flag == 1 )
    {
	while(!standard_cli.interrupt)
	{
        if(standard_cli.appSleep == APP_SLEEP){
            break;
        }
		rc = check_gsm_nw_connection();
		if (rc == 0)
		{
			rc = check_network_connection();
			if(rc == 0)
			{
				rc = 0;
				memset(&end,0,sizeof(end));
				memset(&start,0,sizeof(start));
				time_diff = 0;
				standard_cli.con_status = 1;
				start_check = 0;
				start_loop = 0;
				standard_cli.network_status = 0;
				if(pppd_reset_3 == 1)
				{
					agps_init();
					standard_cli.gps_fd = gps_init();
                                        printf("gps_init() Return value = %d\n",standard_cli.gps_fd);
					modem_reset_count = 0;
					pppd_reset_3 = 0;
				}
			}
			else
			{
				rc = -1;
				standard_cli.con_status = -1;
				if(start_loop == 0)
				{
					memset(&end,0,sizeof(end));
					memset(&start,0,sizeof(start));
					time_diff = 0;
					start_loop = 1;
					clock_gettime(CLOCK_MONOTONIC, &start);
				}
				clock_gettime(CLOCK_MONOTONIC, &end);
				time_diff = time_diff_seconds(&end, &start);
				if(time_diff >= 15)
				{
					printf("Failed to establish internet connection after %d seconds\n",time_diff);
					system("poff");
					system("killall -9 pppd");
					establish_connection();
					sleep(1);
					if(start_check == 0)
					{
						start_check = 1;
						memset(&end,0,sizeof(end));
						memset(&start,0,sizeof(start));
						time_diff = 0;
						clock_gettime(CLOCK_MONOTONIC, &start);
						time_diff = 0;
					}
				}
			}
		}
		else
		{
			if(start_loop == 0)
			{
				memset(&end,0,sizeof(end));
				memset(&start,0,sizeof(start));
				time_diff = 0;
				start_loop = 1;
				clock_gettime(CLOCK_MONOTONIC, &start);
			}
			standard_cli.con_status = -1;
			clock_gettime(CLOCK_MONOTONIC, &end);
			time_diff = time_diff_seconds(&end, &start);
			if(time_diff >= 30 && pppd_reset_1 == 0)
			{
				printf("Failed to establish internet connection after %d seconds\n",time_diff);
				rc = -1;
				system("poff");
				system("killall -9 pppd");
				sleep(1);
				establish_connection();
				pppd_reset_1 = 1;
				sleep(1);
			}
			else if(time_diff > 30 && time_diff <= 45 && pppd_reset_2 == 0)
			{
				printf("Failed to establish internet connection after %d seconds\n",time_diff);
				system("poff");
				system("killall -9 pppd");
				sleep(1);
				rc = set_gsm_flight_mode_off();
				sleep(2);
				rc = set_gsm_flight_mode_on();
				sleep(1);
				rc = get_gsm_sim_status();
				if(rc == 0)
				{

					printf("SIM is inserted\n");
				}
				pppd_reset_2 = 1;
				establish_connection();
				sleep(1);
			}
			if(time_diff >= 60)
			{
				printf("Failed to establish internet connection after %d seconds \n",time_diff);
				if(modem_reset_count > 60)
                                {
                                        printf("RESTART DEVICE\n");
                                        app_deinit();
                                        system("reboot");
                                }
				gps_deinit(standard_cli.gps_fd);
				standard_cli.gps_fd = 0;
				printf("*************** standard_cli.gps_fd %d\n",standard_cli.gps_fd);
				sleep(1);
				gsm_modem_off();
				sleep(2);
				gsm_modem_on();
				sleep(2);
				pppd_reset_3 = 1;
				establish_connection();
				sleep(2);
				modem_reset_count = modem_reset_count + 1;
				if(modem_reset_count == 3)
				{
					standard_cli.network_status = 1;
				}
				memset(&end,0,sizeof(end));
                                memset(&start,0,sizeof(start));
                                time_diff = 0;
                                pppd_reset_1 = 0;
                                pppd_reset_2 = 0;
				start_check = 0;
				start_loop = 0;
			}      
		}
		sleep(3);
	}
	memset(&start,0,sizeof(start));
	memset(&end,0,sizeof(end));
	printf("reset_network_connection () rc --\n");
    }
    else
    {
    }
    acc_thread_flag = 0;
    printf("acc_thread exit \n");

}

int thread_init()
{
	int ret = 0;
	standard_cli.ready = 1;
	if(pthread_create(&(p_tid[0]), NULL, (void *) process_data, NULL) != 0)
	{
		ret = -1;
	}

	else
	{
		if(pthread_detach((p_tid[0])) == 0)
		{
			printf("process_data thread detached successfully\n");
            can_thread_flag = 1;
		}	
		if(pthread_create(&(p_tid[1]), NULL, (void *) acc_thread, NULL) != 0)
		{
			ret = -1;
		}
		else
		{
			if(pthread_detach((p_tid[1])) == 0)
			{
				printf("Accelerometer Thread detached successfully\n");
                acc_thread_flag = 1;
			}
			if(pthread_create(&(p_tid[2]), NULL, (void *) gps_thread, NULL) != 0)
			{
				ret = -1;
			}
			else
			{
				if(pthread_detach((p_tid[2])) == 0)
				{
					printf("GPS thread detached successfully\n");
                    gps_thread_flag = 1;
				}
				if(pthread_create(&(p_tid[3]), NULL, (void *) gyro_thread, NULL) != 0)
				{
					ret = -1;
				}
				else
				{
					if(pthread_detach((p_tid[3])) == 0)
					{
						printf("Gyro_data thread detached successfully\n");
                        gyro_thread_flag = 1;
					}
					if(pthread_create(&(p_tid[4]), NULL, (void *) BLE_connection_status, NULL) != 0)
					{
						ret = -1;
					}
					else
					{
						if(pthread_detach((p_tid[4])) == 0)
						{
							printf("BLE_connection_status thread detached successfully\n");
                            BLE_connection_status_flag = 1;
						}
					}
				}
			}
		}
	}

	return ret;
}

int frame_gyro_pkt_in_json(char * buffer, gyroscope_api_priv * gdata, char *ts)
{           
        sprintf(buffer,"{\"ts\":\"%s\",\"imei\":%s,\"type\":\"gyroscope\",\"gyro:x-axis\":%f,\"gyro:y-axis\":%f,\"gyro:z-axis\":%f}",ts,standard_cli.device_id,gdata->x,gdata->y,gdata->z);

        return 0;
}           
        
int frame_acc_pkt_in_json(char * buffer, accelerometer_api_priv * adata, char *ts)
{   
    sprintf(buffer,"{\"ts\":\"%s\",\"imei\":%s,\"type\":\"accelerometer\",\"acc:x-axis\":%f,\"acc:y-axis\":%f,\"acc:z-axis\":%f}",ts,standard_cli.device_id,adata->x,adata->y,adata->z);
    
    return 0;
}

int frame_gps_pkt_in_json(char * buffer,struct gps_rmc_t * gps_rmc,char * ts)
{
        if (gps_rmc->gps_valid == 1){
            sprintf(buffer,"{\"ts\":\"%s\",\"imei\":%s,\"type\":\"gps\",\"lt\":%f,\"ln\":%f,\"v\":%d}",ts,standard_cli.device_id,gps_rmc->latitude,gps_rmc->longitude,gps_rmc->gps_valid);
        }
        else{
            if(gps_rmc->gps_init_fix == 0){
                sprintf(buffer,"{\"ts\":\"%s\",\"imei\":%s,\"type\":\"gps\",\"v\":%d}",ts,standard_cli.device_id,gps_rmc->gps_valid);
            }
            else{
                sprintf(buffer,"{\"ts\":\"%s\",\"imei\":%s,\"type\":\"gps\",\"lt\":%f,\"ln\":%f,\"v\":%d}",ts, standard_cli.device_id, gps_rmc->latitude, gps_rmc->longitude, 0);
            }
        }       
    return 0;
} 

void acc_thread(void)
{
    int rc = E_SUCCESS;
    char ts[64] = {0};
    char buffer [500]= {0};
    if( acc_thread_flag == 1 )
    {
        while(!standard_cli.interrupt)
        {
            if(standard_cli.appSleep == APP_SLEEP){
                break;
            }
            memset(ts,0,sizeof(ts));
            obd_get_time(ts);
            accelerometer_read(&standard_cli.g_adata);
            printf ("acc: x-axis: %f\ty-axis: %f\tz-axis: %f\n",standard_cli.g_adata.x, standard_cli.g_adata.y, standard_cli.g_adata.z);
            memset(buffer,0,sizeof(buffer));
            frame_acc_pkt_in_json (buffer, &standard_cli.g_adata, ts);
            printf("Buffer value = %s ",buffer);
            rc = send_data_to_ble(buffer);
            if (rc == E_FAILURE)
                printf ("send_data_to_ble failed\n");

            rc = send_to_UDP(buffer);
            if (rc == E_FAILURE)
                printf ("send_data_to_udp failed\n");
            sleep(1);
        }
    }
    else
    {
    }
    acc_thread_flag = 0;
    printf("acc_thread exit \n");
}

void gyro_thread(void)
{
    int rc = E_SUCCESS;
    char ts[64] = {0};
    char buffer [500]= {0};
    if( gyro_thread_flag == 1 )
    {
        while(!standard_cli.interrupt)
        {
            if(standard_cli.appSleep == APP_SLEEP){
                break;
            }
            memset(buffer,0,sizeof(buffer));
            memset(ts,0,sizeof(ts));
            obd_get_time(ts);
            gyroscope_read(&standard_cli.g_gdata);
            printf ("gyro: x-axis: %f\t y-axis: %f\t z-axis: %f\n",standard_cli.g_gdata.x, standard_cli.g_gdata.y, standard_cli.g_gdata.z);
            memset(buffer,0,sizeof(buffer));
            frame_gyro_pkt_in_json (buffer, &standard_cli.g_gdata, ts);
            rc = send_data_to_ble(buffer);
            if (rc == E_FAILURE)
                printf ("send_data_to_ble failed\n");

            rc = send_to_UDP(buffer);
            if (rc == E_FAILURE)
                printf ("send_data_to_udp failed\n");
            sleep(1);
        }
    }
    else
    {
    }
    gyro_thread_flag = 0;
    printf("gyro_thread exit \n");
}

int send_to_UDP(char * buffer) {
    int ret = 0;
    char serv_addr[12]="127.0.0.1";
    struct sockaddr_in si_other;
    int s, slen = sizeof(si_other);

    if ((s = socket(AF_INET, SOCK_DGRAM, IPPROTO_UDP)) == -1) {
        printf("[INFO] [UP] socket\n");
    }

    memset((char *) &si_other, 0, sizeof(si_other));
    si_other.sin_family = AF_INET;
    si_other.sin_port = htons(serv_port_up);
    if (inet_aton((char *) serv_addr,
                (struct in_addr *) &si_other.sin_addr) == 0) {
        fprintf(stderr, " [INFO] [UP] inet_aton() failed\n");
        exit(1);
    }

    if (strlen((char*) buffer) > 0) {
        printf(" [INFO] [UP] Data Recived %s\r\n", buffer);

        ret = sendto(s, buffer,
                strlen((char*) buffer), 0,
                (struct sockaddr *) &si_other, slen);
        if( ret == -1 )
        {
            printf(" [INFO] [UP] sendto");
        }

        memset(buffer, 0, sizeof(*buffer));
        printf(" [INFO] [UP] Data Send\n");
    } else {

        sleep(1); /*if no data wait for 1 sec*/

    }

    close(s);
    printf(" [INFO] [UP] Terminating \r\n");
    return ret;

}

int app_deinit()
{
	j1939_can_deinit();
	IoTHubDeviceClient_LL_Destroy(device_ll_handle);
	IoTHub_Deinit();
	gps_deinit(standard_cli.gps_fd);
	standard_cli.gps_fd = 0;
	system("ifconfig wlan0 down");
	system("killall -9 hostapd");
	system("killall -9 udhcpd");
	system("modprobe -r brcmfmac");
	sleep(5);
	standard_cli.ready = 0;
	sleep(3);
	ble_deinit();
	gsm_modem_off();
	return 0;
}
