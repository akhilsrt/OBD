#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/time.h>
#include <time.h>
#include <app.h>
#include <dirent.h>
volatile int rfcomm_kill_flag = -1;
volatile int connection_flag = -1;
int ble_dis_count = 0;
int send_data_to_ble(char *message)
{
    	int rc = 0;
	FILE * robot;
	printf("send_data_to_ble ++ \n");
	if((connection_flag == 0) && (rfcomm_kill_flag == 0))
	{
		robot = fopen ("/dev/rfcomm0", "w");
		if(robot != NULL)
		{
			rc = fputs(message, robot);
			if(rc < 0)
			{
				printf("Data transfer through ble failed\n");
				rc = -1;
			}
			else
			{
				rc = 0;
			}
			fclose(robot);
		}
	}
	printf("send_data_to_ble ++ \n");
    	return rc;
}
void BLE_connection_status(){

	int rc = -1;
	char buffer[256]={0};
	FILE *fp;
    DIR *path;
    int pid = 0;
    char command[100]={0};
    struct dirent *dir;
    memset(command,0,sizeof(command));
    memset(buffer,0,sizeof(buffer));
    strcpy(buffer,"/sys/devices/soc0/soc/2100000.aips-bus/21f0000.serial/tty/ttymxc3/hci0/");
    sprintf (command, "pidof rfcomm");
    if( BLE_connection_status_flag == 1 )
    {
        while(!standard_cli.interrupt)
        {
            if(standard_cli.appSleep == APP_SLEEP){
                break;
            }

            if (0 == (fp = (FILE*)popen(command, "r")))
            {
                printf("popen() failed.");
            }
            else
            {

                if (fp != NULL)
                {
                    fscanf(fp, "%d", &pid);
                }
                pclose(fp);
            }
            if(pid <= 0)
            {
                rfcomm_kill_flag = 1;
                connection_flag = 1;
                sleep(5);
                system("rm /dev/rfcomm0");
                system("rfcomm release 0");
                system("rfcomm --raw listen /dev/rfcomm0 2 &");
                sleep(1);
            }
            else
            {
                pid = 0;
                path = opendir(buffer);
                if (path)
                {
                    while ((dir = readdir(path)) != NULL)
                    {
                        rc = strncmp(dir->d_name,"hci0",4);
                        if(rc == 0)
                        {
                            rc = access("/dev/rfcomm0", F_OK);
                            if(rc == 0)
                            {	
                                connection_flag = 0;
                                rfcomm_kill_flag = 0;
                                rc =0;
                            }
                            break;
                        }
                        else
                        {
                            connection_flag = 1;
                        }
                    }
                    if(rc != 0)
                    {
                        connection_flag = 1;
                        system("rm /dev/rfcomm0");
                    }
                    if(path)
                    {
                        closedir(path);
                        dir = NULL;
                        path = NULL;
                    }
                }
            }
            usleep(500000);
        }
    }
}
