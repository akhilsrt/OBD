#define _GNU_SOURCE
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <string.h>
#include <signal.h>
#include <errornos.h>
#include <app.h>
#include <sys/time.h>
#include <sys/stat.h>
#include <unistd.h>
#include <time.h>
#include "gsm.h"
#include "gps.h"
#include "stack.h"
#include "common.h"
#include<dirent.h>
FILE *cur_file_fp;
char *file_name = NULL;
char *file_name_txt = NULL;
int file_sequence_number = 1;
int counter = 0;
//Test Buffer Size increased from 6000 to 65535 to avoid segmentation fault. 
unsigned char test_buffer[65535];
//BackUp Test Buffer Size increased from 6000 to 65535 to avoid segmentation fault.
unsigned char test_buffer_bkp[65535];
unsigned char alert_test_buffer[6000];
uint32_t size2 = 0;
int alert_size = 0;
char buffer[31744] = {0};
int size1 = 0;
char file_name_zip[2000] = {0};
volatile int data_pkt_ready = 0;
volatile int data_file_ready = 0;
static int send_timer = 0;
static int bkp_timer = 0;
struct j1939_parameters j_dat;
int ble_data_ready_flag = 0;
volatile int gps_ready = 0;
volatile int bkp_count = 0;
volatile int send_status_bkp = 0;
volatile int curr_count = 0;
volatile int bkp_send_ready = 0;
volatile int bkp_send_stop = 0;
char bkp_file_name[2000] = {0};
int external_power_connected_send = 0;
int external_power_disconnected = 0;
int external_power_disconnected_send = 0;
int external_power_connected = 0;
int curr_send_status = 0;
volatile int bkp_file_send_ready = 0;
volatile int alert_ready = 0;
volatile int alert_send_ready = 0;
char *bkp_alert_file_name_json[200] = {0};
volatile int alert_bkp_count = 0;
int alert_file_read_ptr = 0;
volatile int send_to_ble = 0;

iw_para_t app;   // Configuration parameters, Data buffer and related variables
iw_hpara_t hApp = &app;

void obd_get_time (char *timebuf)
{
    struct timeval tv;
    struct tm* ptm;
    char time_string[40];
    long milliseconds;

    gettimeofday (&tv, NULL);
    ptm = localtime (&tv.tv_sec);

    strftime (time_string, sizeof (time_string), "%Y-%m-%dT%H:%M:%S", ptm);

    milliseconds = tv.tv_usec / 1000;

    sprintf (timebuf,"%s.%03ldZ", time_string, milliseconds);
}

void sigalrm_handler( int sig )
{
    if(standard_cli.can_status == 1){
	printf("ALARMMMMMMMMMMMMMMMM \n");
	data_pkt_ready = 1;
	process_pkts();
	if(++bkp_timer == 10)
	{
		if(bkp_count > 0)
		{
			bkp_send_ready = 1;
		}
		bkp_timer = 0;
	}
	if(++send_timer == 590)
	{
		send_timer = 0;
		bkp_send_stop = 1;
	}
    }
}

#if 1 
void controller_function( void )
{
    int counter = 0;
    int rc = E_SUCCESS;
    standard_cli.init_flag = 0;
    gps_thread_flag = 0;
    acc_thread_flag = 0;
    can_thread_flag = 0;
    gyro_thread_flag = 0;
    reset_connection_flag = 0;
    BLE_connection_status_flag = 0;
    while(1){
        if( access( "filename", F_OK ) == 0 ) {
            sleep(2);
init:       
            printf("Before CAN LOCK in controller function\n");
            pthread_mutex_lock(&can_lock);
            printf("After CAN LOCK in controller function\n");
            sleep(2);
            if(standard_cli.init_flag == 0){
                printf("Before J1939 CAN init\n");
                rc = j1939_can_init();
                printf("After J1939 CAN init\n");
                if(rc != E_SUCCESS){
                    counter++;
                    printf("Counter Value is *************************%d\n",counter);

                    printf("Before CAN UNLOCK in controller function\n");
                    pthread_mutex_unlock(&can_lock);
                    printf("After CAN UNLOCK in controller function\n");
                    if(counter > 10){
                        rc = thread_init();
                        if (rc == E_FAILURE)
                        {
                            printf("thread_init failed \n");
                        }
                        sleep( 2 );

                        sys_sleep();
                        rc = config_timer_wakeup( ENABLE, 60 );
                        
                        rc = config_can_wakeup(ENABLE);
                        if (rc == E_FAILURE)
                        {
                            printf("config_can_wakeup failed \n");
                        }
                        rc = push_device_to_sleep();
                        if (rc == E_FAILURE)
                        {
                            printf("sys_sleep failed \n");
                        }
                        sys_wake();
                        counter = 0;
                        goto init;
                    }
                }
                else
                {
                    standard_cli.can_status = 1;
                    rc = thread_init();
                    if (rc == E_FAILURE)
                    {
                        printf("thread_init failed \n");
                    }
                    sleep( 5 );
                    standard_cli.init_flag = 1;
                }
            }
            else{
                sys_sleep();
                rc = config_can_wakeup(ENABLE);
                if (rc == E_FAILURE)
                {
                    printf("config_can_wakeup failed \n");
                }
                rc = push_device_to_sleep();
                if (rc == E_FAILURE)
                {
                    printf("sys_sleep failed \n");
                }
                sys_wake();

                rc = thread_init();
                if (rc == E_FAILURE)
                {
                    printf("thread_init failed \n");
                }
                sleep( 5 );
            }
        }
        sleep(1);
    }
    return;
}

void sys_sleep (void)
{
    int rc = E_SUCCESS;
    printf("system sleep in sys_sleep()\n");

    standard_cli.interrupt = 1;
    standard_cli.appSleep = APP_SLEEP;
    standard_cli.can_status = 0;
    
    while( 1 )
    {

        if( ( ( acc_thread_flag == 0 ) && ( gps_thread_flag == 0 ) && ( can_thread_flag == 0 ) && ( gyro_thread_flag == 0 ) && ( BLE_connection_status_flag == 0 ) ) == 0 )
        {
            printf("%s - All threads got exited \n", __FUNCTION__ );
            break;
        }
        sleep( 1 );
    }

    sleep(2);//to wait till all thread_exit

    rc = acc_deinit();
    if (rc != E_SUCCESS)
        printf ("ACC_deinit failed\n");

    sleep(2);

    rc = gyro_deinit();
    if (rc != E_SUCCESS)
        printf ("Gyro_deinit failed\n");

    sleep(2);

    rc = wifi_deinit( WIFI_HOSTAPD_MODE );
    if (rc != E_SUCCESS)
        printf ("Wifi_deinit failed\n");

    sleep(2);

    rc = gps_deinit(standard_cli.gps_fd);
    printf("GPS Deinitialization return value %x\n",rc);

    sleep(2);
    
    while(1){
        rc = network_monitor_disable( );
        printf("Network Monitor Disable rc = %x\n",rc);
        if(rc == E_SUCCESS){
            break;
        }
        else{
            sleep(1);
        }
    }

    rc = deinit();
    printf ("hw_deinit return value %x\n",rc);

    sys_sleep_completed();// to indicate sleep completion status to library

    return;
}

void sys_wake (void)
{
    int rc = E_SUCCESS;
    standard_cli.interrupt = 0;
    char iccid[100] = {0};
    char device_id[100] = {0};
    standard_cli.appSleep = APP_WAKE;
    char connection_String[200];
    standard_cli.con_status = -1;
    standard_cli.cloud_status = -1;
    standard_cli.can_status = 1;
    standard_cli.network_status = 0;
    standard_cli.can_alert_not_available = 0;
    standard_cli.can_alert_available = 0;
    device_ll_handle = NULL;
    printf("!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!! START !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!\n");

    rc = init(1);
    printf ("hw_init in syswake %x\n",rc);  

    rc = check_gsm_modem_status();
    if(rc != 0)
    {
        rc = gsm_modem_on( "0000", 4 );
        printf("gsm_modem_on() Return value = %x\n",rc);
    }

    rc = get_gsm_sim_iccid(iccid,sizeof(iccid));
    if(rc == E_SUCCESS)
    {
        strcpy(standard_cli.iccid, iccid);
        printf("ICCID[%s]\n", standard_cli.iccid);
    }

    rc = get_gsm_imei(device_id, sizeof( device_id ));
    if(rc == E_SUCCESS)
    {
        strcpy(standard_cli.device_id, device_id);
        printf("Device ID [%s]\n", standard_cli.device_id);
    }

    rc = set_gsm_network_mode(4);
    printf("rc set_gsm_network_mode() %x\n",rc);

    rc = agps_init();
    printf("agps_init return value%x\n",rc);

    memset(connection_String, 0, sizeof(connection_String));
    memset(standard_cli.con_string,0,sizeof(standard_cli.con_string));

    strcpy(standard_cli.con_string,connection_String);
    get_device_id(connection_String);    


    rc = acc_init();
    printf("Acc init return value%x\n",rc);

    sleep(2);

    rc = gyro_init();
    printf("Gyro init return value%x\n",rc);

    sleep(2);

    standard_cli.gps_fd = gps_init();
    if (standard_cli.gps_fd == E_FAILURE)
    {
        printf("gps init faild\n");
    }

    sleep(2);

    rc = wifi_init( WIFI_HOSTAPD_MODE );
    if(rc != E_SUCCESS)
        printf("Wifi init failed at callback option %x\n",rc);

    standard_cli.appSleep = APP_WAKE;

    return;
}

#endif

void process_data()
{
    uint8_t data[2000]={0};
    int length;
    FILE *file;
    int n = 0;
    int m = 0;
    int j = 0;
    unsigned long int var_pgn = 0;
    int rc = 0, i;
    signal(SIGALRM, sigalrm_handler);
    int ptode_state = 0;
    int cruice_state = 0;
    int break_state = 0;
    int clutch_state = 0;
    int pto_state = 0;
    int driver1_card_state = 0;
    int driver2_card_state = 0;
    int driver1_working_state = 0;
    int driver2_working_state = 0;
    int driver1_rel_state = 0;
    int driver2_rel_state = 0;
    char driver1_id[70] = {0};
    char driver2_id[70] = {0};
    char vin[100] = {0};
    int len = 0;
    char can_temp[50] = {0};
    uint16_t service1;
    char *main_buffer = NULL;
    char ts[64] = {0};
    double bat_volt = 0;
    size_t size = 0;
    uint8_t buff_app[8] = {0x0};
    double de_value;
    int fail_counter = 0;
    int axle_location = 0;
    memset(j_dat.vin,0,sizeof(j_dat.vin));
    memset(j_dat.driver1_id,0,sizeof(j_dat.driver1_id));
    memset(j_dat.driver2_id,0,sizeof(j_dat.driver2_id));
    alarm(1);
    if( can_thread_flag == 1 )
    {
        while(!standard_cli.interrupt)
        {
            if( access( "filename", F_OK ) == 0 ) {
                if(standard_cli.appSleep == APP_SLEEP)
                {
                    break;
                }
                memset(ts,0,sizeof(ts));
                obd_get_time(ts);
                if(standard_cli.can_status == 1)
                {
                    pthread_mutex_lock(&udp_lock);
                    file = fopen("filename", "r");
                    if(file == NULL)
                    {
                        printf("Error!");
                        exit(1);
                    }
                    rc = fseek(file, 0, SEEK_END); /* Go to end of file */
                    if(rc != E_SUCCESS)
                    {
                        printf("FSEEK FAILED\n");
                    }
                    size = ftell(file);
                    rewind(file);
                    main_buffer = malloc((size + 1) * sizeof(*main_buffer));
                    fread(main_buffer, size, 1, file);
                    main_buffer[size] = '\0';
                    rc = fclose(file);
                    if(rc != E_SUCCESS)
                    {
                        printf("File closed failed\n");
                    }
                    if(file_set_flag == 0){
                        len = 0;
                        m = 0;
                        n = 0;
                        j = 0;
                        PID_no = 0;
                        memset(&hApp->obdType_ht,0,sizeof(hApp->obdType_ht));
                        while(main_buffer[len+2]!='\0')
                        {
                            while(main_buffer[len]!=',')
                            {
                                can_temp[j]=main_buffer[len];
                                len++;
                                j++;
                            }
                            len++;
                            j=0;
                            hApp->obdType_ht[m].service = (uint16_t) strtol(can_temp,NULL,10);
                            m++;
                            memset(can_temp, 0, sizeof(can_temp));
                            while(main_buffer[len]!='*')
                            {
                                can_temp[j]=main_buffer[len];
                                len++;
                                j++;
                            }
                            if(main_buffer[len]=='\r')
                            {
                                len++;
                            }
                            len++;
                            j=0;
                            strcpy(hApp->obdType_ht[n].Json_descript, can_temp);
                            n++;
                            memset(can_temp, 0, sizeof(can_temp));
                            PID_no++;
                            file_set_flag = 1;
                        }
                        if(main_buffer != NULL){
                            free(main_buffer);
                            main_buffer = NULL;
                        }
                    }
                    for (i=0;i<PID_no;i++)
                    {
                        memset(buff_app,0,sizeof(buff_app));
                        service1 = (uint16_t)hApp->obdType_ht[i].service;
                        memset(&data,0,sizeof(data));
                        memset(driver1_id,0,sizeof(driver1_id));
                        memset(driver2_id,0,sizeof(driver2_id));
                        memset(vin,0,sizeof(vin));
                        length = 0;
                        var_pgn = 0;
                        de_value = 0;
                        axle_location = 0;
                        rc = j1939_recv_broadcast_response(data,&length,&var_pgn);
                        if(rc != 0){
                            printf ("CAN_resp_recv failed %d\n",rc);
                            fail_counter++;
                            printf("Fail Counter Value is ########################%d\n",fail_counter);
                            if(fail_counter > 10){
                                standard_cli.init_flag = 1;
                                fail_counter = 0;
                                pthread_mutex_unlock(&can_lock);
                            }

                        }    
                        else
                        {
                            fail_counter = 0;
                                                      switch(service1)
                            {
                                case 61444:
                                if(var_pgn == 61444)
                                {
                                    rc = decode_without_xml(data,length,var_pgn,&de_value);
                                    j_dat.eng_speed = de_value;
                                    hApp->CAN_ht[i].output = j_dat.eng_speed;
                                }				
                                                            break;
                                                            case 65265:
                                if(var_pgn == 65265)
                                {
                                                                    rc = decode_without_xml(data,length,var_pgn,&de_value);
                                                                    j_dat.wheel_speed = de_value;
                                    hApp->CAN_ht[i].output = de_value;

                                    j1939_get_clutch_cruice_cntrl_brake_switch_state(data,length,var_pgn,&clutch_state,&break_state,&cruice_state);
                                    j1939_get_pto_state(data,length,var_pgn,&pto_state);
                                    if(clutch_state == E_CLUTCH_SWITCH_PEDAL_RELEASED)
                                    {
                                        j_dat.clutch_switch= 0;
                                        hApp->CAN_ht[i].clutch_switch = j_dat.clutch_switch;
                                    }
                                    else if(clutch_state == E_CLUTCH_SWITCH_PEDAL_DEPRESSED)
                                    {
                                        j_dat.clutch_switch = 1;
                                        hApp->CAN_ht[i].clutch_switch = j_dat.clutch_switch;
                                    }

                                    if(break_state == E_BREAK_SWITCH_PEDAL_RELEASED)
                                    {
                                        j_dat.brake_switch = 0;
                                        hApp->CAN_ht[i].brake_switch = j_dat.brake_switch;
                                    }
                                    else if(break_state == E_BREAK_SWITCH_PEDAL_DEPRESSED)
                                    {
                                        j_dat.brake_switch = 1;
                                        hApp->CAN_ht[i].brake_switch = j_dat.brake_switch;
                                    }

                                    if(cruice_state == E_CRUICE_CNTRL_OFF)
                                    {
                                        j_dat.cruice_cntl_state = 0;
                                        hApp->CAN_ht[i].cruise_state = j_dat.cruice_cntl_state;
                                    }
                                    else if(cruice_state == E_CRUICE_CNTRL_ON)
                                    {
                                        j_dat.cruice_cntl_state = 1;
                                        hApp->CAN_ht[i].cruise_state = j_dat.cruice_cntl_state;
                                    }
                                }
                                                            break;
                                                            case 65132:
                                if(var_pgn == 65132)
                                {
                                                                   rc = decode_without_xml(data,length,var_pgn,&de_value);
                                    j_dat.tachograph_veh_speed = de_value;
                                    hApp->CAN_ht[i].output = j_dat.tachograph_veh_speed;
                                    
                                    j1939_get_driver_card_state(data,length,&driver1_card_state,&driver2_card_state);
                                        if(driver1_card_state == E_DRIVER_CARD_1_NOT_PRESENT)
                                        {
                                            j_dat.driver1_card_state = 0;
                                            hApp->CAN_ht[i].card1_state = j_dat.driver1_card_state;
                                        }
                                        else if(driver1_card_state == E_DRIVER_CARD_1_PRESENT)
                                        {
                                            j_dat.driver1_card_state = 1;
                                            hApp->CAN_ht[i].card1_state = j_dat.driver1_card_state;
                                        }
                                        if(driver2_card_state == E_DRIVER_CARD_2_NOT_PRESENT)
                                        {
                                            j_dat.driver2_card_state = 0;
                                            hApp->CAN_ht[i].card2_state = j_dat.driver2_card_state;
                                        }
                                        else if(driver2_card_state == E_DRIVER_CARD_2_PRESENT)
                                        {
                                            j_dat.driver2_card_state = 1;
                                            hApp->CAN_ht[i].card2_state = j_dat.driver2_card_state;
                                        }
                                        j1939_get_driver_working_state(data,length,&driver1_working_state,&driver2_working_state);
                                        j_dat.driver1_working_state = driver1_working_state;
                                        hApp->CAN_ht[i].working1_state = j_dat.driver1_working_state;

                                        j_dat.driver2_working_state = driver2_working_state;
                                        hApp->CAN_ht[i].working2_state = j_dat.driver2_working_state;

                                        j1939_get_driver_rel_state(data,length,&driver1_rel_state,&driver2_rel_state);
                                        j_dat.driver1_rel_state = driver1_rel_state;
                                        hApp->CAN_ht[i].rel1_state = j_dat.driver1_rel_state;

                                        j_dat.driver2_rel_state = driver2_rel_state;
                                        hApp->CAN_ht[i].rel2_state = j_dat.driver2_rel_state;
                                }
                                                            break;
                                                            case 61443:
                                if(var_pgn == 61443)
                                {
                                                                    rc = decode_without_xml(data,length,var_pgn,&de_value);
                                    j_dat.accelerator_pedal_pos_1 = de_value;
                                    hApp->CAN_ht[i].output = j_dat.accelerator_pedal_pos_1;
                                }
                                                            break;
                                                            case 65276:
                                if(var_pgn == 65276)
                                {
                                                                    rc = decode_without_xml(data,length,var_pgn,&de_value);
                                    j_dat.fuelLevel = de_value;
                                    hApp->CAN_ht[i].output = j_dat.fuelLevel;
                                }
                                                            break;
                                                            case 65257:
                                if(var_pgn == 65257)
                                {   
                                                                    rc = decode_without_xml(data,length,var_pgn,&de_value);
                                    j_dat.total_fuel_used = de_value;
                                    hApp->CAN_ht[i].output = j_dat.total_fuel_used;
                                }
                                                            break;
                                                            case 65253:
                                if(var_pgn == 65253)
                                {
                                                                    rc = decode_without_xml(data,length,var_pgn,&de_value);
                                    j_dat.total_engine_hrs = de_value;
                                    hApp->CAN_ht[i].output = j_dat.total_engine_hrs;
                                }
                                                            break;
                                                            case 65216:
                                if(var_pgn == 65216)
                                {
                                                                    rc = decode_without_xml(data,length,var_pgn,&de_value);
                                    j_dat.service_distance = de_value;
                                    hApp->CAN_ht[i].output = j_dat.service_distance;
                                }
                                                            break;
                                                            case 65258:
                                if(var_pgn == 65258)
                                {
                                                                    rc = decode_without_xml(data,length,var_pgn,&de_value);
                                    j_dat.axle_weight_1 = de_value;
                                    hApp->CAN_ht[i].output = j_dat.axle_weight_1;
                                    rc = get_axle_location(data,length,var_pgn,&axle_location);
                                    if(rc == 0)
                                    {
                                        if(axle_location == 1)
                                        {
                                            j_dat.axle_weight_1 = de_value;
                                            hApp->CAN_ht[i].output = j_dat.axle_weight_1;
                                        }
                                        else if(axle_location == 2)
                                        {
                                            j_dat.axle_weight_2 = de_value;
                                            hApp->CAN_ht[i].output = j_dat.axle_weight_2;
                                        }
                                        else if(axle_location == 3)
                                        {
                                            j_dat.axle_weight_3 = de_value;
                                            hApp->CAN_ht[i].output = j_dat.axle_weight_3;
                                        }
                                        else
                                        {
                                        }
                                    }
                                }
                                                            break;
                                                            case 65217:
                                if(var_pgn == 65217)
                                {
                                                                    rc = decode_without_xml(data,length,var_pgn,&de_value);
                                    j_dat.odometer = de_value;
                                    hApp->CAN_ht[i].output = j_dat.odometer;
                                }
                                                            break;
                                                            case 64777:
                                if(var_pgn == 64777)
                                {
                                                                    rc = decode_without_xml(data,length,var_pgn,&de_value);
                                    j_dat.high_res_total_fuel_used = de_value;
                                    hApp->CAN_ht[i].output = j_dat.high_res_total_fuel_used;
                                }
                                                            break;
                                                            case 65262:
                                if(var_pgn == 65262)
                                {
                                                                    rc = decode_without_xml(data,length,var_pgn,&de_value);
                                    j_dat.eng_coolant_temp = de_value;
                                    hApp->CAN_ht[i].output = j_dat.eng_coolant_temp;
                                }
                                                            break;
                                                            case 65260:
                                if(var_pgn == 65260)
                                {
                                                                    rc = decode_without_xml(data,length,var_pgn,&de_value);
                                    memset(vin,0,sizeof(vin));
                                    decode_vehicle_identification_number(data,length,vin);
                                    len = 0;
                                    len = strlen(vin);
                                    strncpy(j_dat.vin,vin,len+2);
                                    hApp->CAN_ht[i].output = *j_dat.vin;
                                }
                                                            break;
                                                            case 65131:
                                if(var_pgn == 65131)
                                {
                                    memset(driver1_id,0,sizeof(driver1_id));
                                    memset(driver2_id,0,sizeof(driver1_id));
                                    memset(j_dat.driver1_id,0,sizeof(j_dat.driver1_id));
                                    memset(j_dat.driver2_id,0,sizeof(j_dat.driver2_id));
                                    j1939_tacho_get_drivers_id(data,length,driver1_id,driver2_id);
                                    len = 0;
                                    len = strlen(driver1_id);
                                    strncpy(j_dat.driver1_id,driver1_id,len+2);
                                    len = 0;
                                    len = strlen(driver2_id);
                                    strncpy(j_dat.driver2_id,driver2_id,len+2);
                                }
                                                            break;
                                                            case 64932:
                                if(var_pgn == 64932)
                                {
                                    j1939_get_ptode_state(data,length,var_pgn,&ptode_state);
                                }
                                if(j_dat.high_res_total_fuel_used > 0)
                                {
                                    j_dat.engine_total_fuel_used = j_dat.high_res_total_fuel_used;
                                    hApp->CAN_ht[i].output = j_dat.engine_total_fuel_used;
                                }
                                else
                                {
                                    j_dat.engine_total_fuel_used = j_dat.total_fuel_used;
                                    hApp->CAN_ht[i].output = j_dat.engine_total_fuel_used; 
                                }
                                if(ptode_state == 1 || pto_state == 5)
                                {
                                    j_dat.pto_state = 1;
                                    hApp->CAN_ht[i].output = j_dat.pto_state;
                                }
                                if(ptode_state == 0 && pto_state == 0)
                                {
                                    j_dat.pto_state = 0;
                                    hApp->CAN_ht[i].output = j_dat.pto_state;
                                }
                                else if((ptode_state == 2 || ptode_state == 3 || ptode_state == 0) && (pto_state == 5))
                                {
                                    j_dat.pto_state = 1;
                                    hApp->CAN_ht[i].output = j_dat.pto_state;
                                }
                                else if(pto_state == 31 || (pto_state == 0  && ptode_state == 1))
                                {
                                    j_dat.pto_state = 1;
                                    hApp->CAN_ht[i].output = j_dat.pto_state;
                                }
                                else if((pto_state == 31 || pto_state == 0) && (ptode_state == 2 || ptode_state == 3 || ptode_state == 0))
                                {
                                    j_dat.pto_state = 1;
                                    hApp->CAN_ht[i].output = j_dat.pto_state;
                                }
                                                            break;
                            }
                            }

                    check_adc_voltage(&bat_volt);
                    memset(buffer,0,sizeof(buffer));
                    memset(ts,0,sizeof(ts));
                    obd_get_time(ts);
                    CAN_Json_output(buffer, service1, bat_volt, ts);
                    pthread_mutex_unlock(&udp_lock);
              }
              i =0;
                }
            }
        }
}  
else
{
}
can_thread_flag = 0;
printf("can_thread exits\n");

}
int frame_pkt_in_json(char *buffer,char *ts,char *device_id,char *mac_address,char *sw_version,j1939_parameters *data)
{
    printf("frame_pkt_in_json Engine Temperature :%f ++\n",data->eng_coolant_temp);
    printf("frame_pkt_in_json Engine Temperature :%f ++\n",data->eng_speed);
    sprintf(buffer,"{\"deviceId\":\"%s\",\"macAddress\":\"%s\",\"startDate\":\"%s\",\"swVersion\":\"%s\",\"vehicleId\":\"%s\",\"tcoVehicleSpeed\":%f,\"vehicleSpeed\":%f,\"clutchSwitch\":%d,\"brakeSwitch\":%d,\"cruiseControlState\":%d,\"ptoState\":%d,\"pedalPosition\":%f,\"odometer\":%f,\"fuelLevel\":%f,\"totalConsumption\":%f,\"totalEngineHours\":%d,\"nextService\":%f,\"engineTemperature\":%f,\"engineSpeed\":%f,\"axleWeight1\":%f,\"axleWeight2\":%f,\"axleWeight3\":%f,\"driver1CardId\":\"%s\",\"driver1CardState\":%d,\"driver1WorkingState\":%d,\"driver1RelState\":%d,\"driver2CardId\":\"%s\",\"driver2CardState\":%d,\"driver2WorkingState\":%d,\"driver2RelState\":%d,\"longitude\":%f,\"latitude\":%f,\"height\":%f}\n",device_id,mac_address,ts,sw_version,data->vin,data->tachograph_veh_speed,data->wheel_speed,data->clutch_switch,data->brake_switch,data->cruice_cntl_state,data->pto_state,data->accelerator_pedal_pos_1,data->odometer,data->fuelLevel,data->engine_total_fuel_used,data->total_engine_hrs,data->service_distance,data->eng_coolant_temp,data->eng_speed,data->axle_weight_1,data->axle_weight_2,data->axle_weight_3,data->driver1_id,data->driver1_card_state,data->driver1_working_state,data->driver1_rel_state,data->driver2_id,data->driver2_card_state,data->driver2_working_state,data->driver2_rel_state,standard_cli.g_gps.gps_rmc.latitude,standard_cli.g_gps.gps_rmc.longitude,standard_cli.g_gps.gps_gga.altitude);
    printf("frame_pkt_in_json --\n");
    return 0;
}

char parse_configuration(char *buffer){
    FILE *file;
    int rc = E_SUCCESS;
    PID_no=0;
    file = fopen("filename", "w");
    if(file == NULL)
    {
        printf("Error!");
        exit(1);
    }
    int results = fputs(buffer, file);
    if (results == EOF) {
        printf("No contents inside file\n");
    }
    rc = fclose(file);
    if(rc == E_SUCCESS)
    {
        printf("File closed successfully\n");
    }
    return 0;
}



int CAN_Json_output( char * CAN_buffer, uint16_t pgn_value, double battery_vol, char * ts)
{
    int k=0;
    char temp_buff[5000], battery[ 20 ], temp_buff1[5000];
    sprintf(CAN_buffer,"{\"ts\":\"%s\",\"imei\":%s,\"type\":\"engine\"",ts,standard_cli.device_id);
    for(k=0;k<PID_no;k++)
    {
        if(strstr(hApp->obdType_ht[k].Json_descript,"DTC") == NULL ){
            strcat(CAN_buffer,",");
            memset(temp_buff, 0 , sizeof(temp_buff));
            memset(temp_buff1, 0 , sizeof(temp_buff1));
            sprintf(temp_buff,"\"%s\":\"%ld\"",hApp->obdType_ht[k].Json_descript,hApp->CAN_ht[k].output);
            strcat(CAN_buffer,temp_buff);
            if(pgn_value == 65265){
                sprintf(temp_buff1,",\"clutch_switch\":\"%ld\",\"brake_switch\":\"%ld\",\"cruise_state\":\"%ld\"",hApp->CAN_ht[k].clutch_switch,hApp->CAN_ht[k].brake_switch,hApp->CAN_ht[k].cruise_state);
            }
            else if(pgn_value == 65132){
                sprintf(temp_buff1,",\"card1_state\":\"%ld\",\"card2_state\":\"%ld\",\"working1_state\":\"%ld\",\"working2_state\":\"%ld\",\"rel1_state\":\"%ld\",\"rel2_state\":\"%ld\"",hApp->CAN_ht[k].card1_state,hApp->CAN_ht[k].card2_state,hApp->CAN_ht[k].working1_state,hApp->CAN_ht[k].working2_state,hApp->CAN_ht[k].rel1_state,hApp->CAN_ht[k].rel2_state);
            }
            else{
                
            }
            }
    }
    strcat(CAN_buffer,temp_buff1);
    strcat(CAN_buffer,",");
    memset(battery, 0 , sizeof(battery));
    sprintf(battery,"\"bat_volt\":%lf",battery_vol);
    strcat(CAN_buffer,battery);
    strcat(CAN_buffer,"}");
    return 0;
}

void process_pkts()
{
    int rc = E_SUCCESS;
    signal(SIGALRM, sigalrm_handler);
    alarm(1);
    if( can_thread_flag == 1 )
    {
        if(data_pkt_ready == 1)
        {
            printf("CAN Buffer value = %s \n",buffer);
            rc = send_data_to_ble(buffer);
            if(rc == E_FAILURE){
                printf("Sending data to BLE failed\n");
            }
            rc = send_to_UDP(buffer);
            if(rc == E_FAILURE){
                printf("Sending data to UDP failed\n");
            }
        }
    }
    else{
    }
    return;
}
void gps_thread(void)
{
    int rc = E_SUCCESS;
    char ts[64] = {0};
    char buffer [500]= {0};
    if( gps_thread_flag == 1 )
    {
        while(!standard_cli.interrupt)
        {
            if(standard_cli.appSleep == APP_SLEEP){
                break;
            }
            memset(ts,0,sizeof(ts));
            obd_get_time(ts);
            rc = get_gps_data_wrapper(&standard_cli.g_gps);
            if(rc < E_SUCCESS)
            {
                printf("read_req_data failed!\n");
            }
            memset(buffer,0,sizeof(buffer));
            frame_gps_pkt_in_json (buffer, &standard_cli.g_gps.gps_rmc, ts);
            printf("Buffer value = %s ",buffer);
            send_data_to_ble(buffer);
            rc = send_to_UDP(buffer);
            if (rc == E_FAILURE)
                printf ("send_data_to_cloud failed\n");
            sleep(1);
        }
    }
    else
    {
    }
    gps_thread_flag = 0;
    printf("gps_thread exit \n");
}

