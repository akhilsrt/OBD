#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <string.h>
#include <errornos.h>
#include <app.h>
#include <sys/time.h>
#include <time.h>
#include <pthread.h>
#include <unistd.h>
#include "iothub_client_ll_uploadtoblob.h"
#include <sys/stat.h>
#include "gsm.h"
#include "gps.h"
#include "common.h"
#define serv_port_down 1687

FILE *fp;
unsigned char const test_buffer[4098];
size_t size1;

int main()
{
    int recv_from = 0;	
    int rc = 0;
    char device_id[100] = {0};
    char iccid[100] = {0};
    char connection_String[200];
    int sockfd; /* socket */
    int clientlen; /* byte size of client's address */
    struct sockaddr_in serveraddr; /* server's addr */
    struct sockaddr_in clientaddr; /* client addr */
    int optval;
    int n;
    pthread_mutex_init( &lock, NULL );
    pthread_mutex_init( &udp_lock, NULL );
    pthread_mutex_init( &can_lock, NULL );

    standard_cli.con_status = -1;
    standard_cli.cloud_status = -1;
    standard_cli.can_status = -1;
    standard_cli.network_status = 0;
    standard_cli.can_alert_not_available = 0;
    standard_cli.can_alert_available = 0;
    device_ll_handle = NULL;
    printf("!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!! START !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!\n");
    //	rc = convert_existing_file();

    rc = init(1);
    printf("Init return value %x\n",rc);

    rc = check_gsm_modem_status();
        if(rc != 0)
        {
            rc = gsm_modem_on( "0000", 4 );
            printf("gsm_modem_on() Return value = %x\n",rc);
        }

        printf("\nLINE %d\n", __LINE__);
    
    rc = get_gsm_sim_iccid(iccid,sizeof(iccid));
    if(rc == E_SUCCESS)
    {
        strcpy(standard_cli.iccid, iccid);
        printf("ICCID[%s]\n", standard_cli.iccid);
    }

    rc = get_gsm_imei(device_id, sizeof( device_id ));
    if(rc == E_SUCCESS)
    {
        strcpy(standard_cli.device_id, device_id);
        printf("Device ID [%s]\n", standard_cli.device_id);
    }
    
    rc = set_gsm_network_mode(4);
    printf("rc set_gsm_network_mode() %x\n",rc);

    rc = agps_init();
    printf("agps_init return value%x\n",rc);

    memset(connection_String, 0, sizeof(connection_String));
    memset(standard_cli.con_string,0,sizeof(standard_cli.con_string));

    strcpy(standard_cli.con_string,connection_String);
    get_device_id(connection_String);

    sockfd = socket(AF_INET, SOCK_DGRAM, 0);
    if (sockfd < 0)
        printf("ERROR opening socket");
    optval = 1;
    setsockopt(sockfd, SOL_SOCKET, SO_REUSEADDR, (const void *) &optval,
            sizeof(int));

    memset(&serveraddr, 0, sizeof(serveraddr));
    serveraddr.sin_family = AF_INET;
    serveraddr.sin_addr.s_addr = htonl(INADDR_ANY);
    serveraddr.sin_port = htons(serv_port_down);

    if (bind(sockfd, (struct sockaddr *) &serveraddr, sizeof(serveraddr)) < 0)
        printf("ERROR on binding");
    standard_cli.gps_fd = gps_init();
    if (standard_cli.gps_fd == E_FAILURE)
    {
        printf("gps init faild\n");
    }

    rc = acc_init();
    printf("ACC init return value%x\n",rc);

    rc = gyro_init();
    printf("Gyro init return value%x\n",rc);

    rc = wifi_init(WIFI_HOSTAPD_MODE);
    printf("wifi return vlue %x\n",rc);
    
    standard_cli.interrupt = 0;

    standard_cli.ready = 0;
    memset(j1939_p.mac_address,0,sizeof(j1939_p.mac_address));
    get_mac_address("hci0",j1939_p.mac_address);

#if 1
    PID_no = 0;
    while(1)
    {
        sleep(3);
        if(recv_from == 0){
            recv_from = 1;
            if(recv_from == 1){
                if (pthread_create(&(p_tid[5]), NULL, (void*) controller_function, NULL) != 0) {
                    rc = E_FAILURE;
                }
                else{
                    printf("controller_function is created\n");
                    if (pthread_detach((p_tid[5])) == 0)
                    {   
                        printf("Controller Function Thread detached successfully %d\n",errno);
                    }
                }
            }
        }
    
#endif
#if 1

        memset(buf, 0, BUFSIZE);
        n = recvfrom(sockfd, buf, BUFSIZE, 0, (struct sockaddr *) &clientaddr,
                (socklen_t *) &clientlen); /*Receive adta from udp client*/
        if (n < 0)
            printf("ERROR in recvfrom");
        if (n == 0) {
            usleep(500); /*wait some time*/
            continue;
        }
        printf("%s\r\n",buf);
        printf("Before CAN_LOCK in while*************\n");
        pthread_mutex_lock(&udp_lock);
        printf("After CAN_LOCK in while*************\n");
        parse_configuration(buf);
        file_set_flag = 0;
        printf("Before CAN_UNLOCK in while*************\n");
        pthread_mutex_unlock(&udp_lock);
        printf("After CAN_UNLOCK in while*************\n");
    }
#endif

    return 0;
}

int time_diff_seconds(struct timespec *time_end, struct timespec *time_start)
{
    int ret = 0;
    ret = time_end->tv_sec - time_start->tv_sec;
    return ret;
}
int time_diff_nano_seconds(struct timespec *time_end, struct timespec *time_start)
{
    int ret = 0;
    ret = time_end->tv_nsec - time_start->tv_nsec;
    return ret;
}

int get_device_id(char *con_string)
{
    char str[256] = {0};
    char* token;
    char temp[240] ={0};
    memset(str,0,sizeof(str));
    memset(temp,0,sizeof(temp));
    memset(standard_cli.dev_id,0,sizeof(standard_cli.dev_id));
    strcpy(str,con_string);
    printf("con_string %s\n",str);
    token = strtok(str, ";");
    while (token != NULL)
    {
        printf("%s\n", token);
        if(strstr(token,"DeviceId"))
        {
            strcpy(temp,token);
            printf("%s\n", temp);
            token = NULL;
            break;
        }
        token = strtok(NULL, ";");
    }
    token = strtok(temp, "=");
    while (token != NULL)
    {
        printf("%s\n", token);
        strcpy(standard_cli.dev_id,token);
        if(token == NULL)
        {
            token = NULL;
            break;
        }
        token = strtok(NULL,"=");
    }
    printf("DEVICE ID %s\n",standard_cli.dev_id);
    return 0;
}

